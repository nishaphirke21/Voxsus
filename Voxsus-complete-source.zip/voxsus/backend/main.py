import asyncio
import json
import os
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from analysis.audio import MAX_BYTES, decode, peaks
from analysis.context_analysis import analyze_context
from analysis.prosody import analyze_prosody
from analysis.synthetic_detector import detector
from backend import storage
from backend.limits import BodyLimitMiddleware
from risk.engine import fuse
from risk.policy import evaluate

ROOT = Path(__file__).resolve().parents[1]
SCENARIOS = json.loads((ROOT / "samples/scenarios.json").read_text(encoding="utf-8"))
analysis_gate = asyncio.Semaphore(1)


@asynccontextmanager
async def lifespan(app):
    storage.connect().close()
    task = (
        asyncio.create_task(asyncio.to_thread(detector.warmup))
        if os.getenv("VOXSUS_WARMUP", "1") == "1"
        else None
    )
    yield
    if task:
        task.cancel()


app = FastAPI(title="Voxsus voice integrity", version="0.1.0", lifespan=lifespan)
app.add_middleware(BodyLimitMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173", "http://127.0.0.1:4173"],
    allow_methods=["GET", "POST", "PUT", "PATCH"],
    allow_headers=["Content-Type"],
)


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "synthetic": detector.health(),
        "speaker": "not_configured",
        "transcription": "manual_transcript",
        "prosody": "heuristic",
        "context": "english_rules",
        "mode": "local_prototype",
    }


@app.get("/api/scenarios")
def scenarios():
    return SCENARIOS


class DemoRequest(BaseModel):
    scenario: Literal["genuine", "cloned"]
    workflow: Literal["normal", "payment", "privileged"] = "payment"


@app.post("/api/demo", status_code=201)
def demo(body: DemoRequest):
    fixture = next(s for s in SCENARIOS if s["id"] == body.scenario)
    scores = {key: fixture[key] for key in ("synthetic", "speaker", "prosody", "context")}
    risk = fuse(scores)
    context = analyze_context(fixture["transcript"])
    policy = evaluate(risk["score"], body.workflow, storage.settings(), True, context["signals"])
    return storage.save(
        {
            "id": "DEMO-" + uuid.uuid4().hex[:8].upper(),
            "created": storage.now(),
            "mode": "DEMO_ANALYSIS",
            "identity": fixture["identity"],
            "transcript": fixture["transcript"],
            "transcript_source": "SCRIPTED_SCENARIO",
            "risk": risk,
            "policy": policy,
            "timeline": fixture["progression"],
            "signals": context["signals"],
            "metrics": {k: {"score": v, "source": "DEMO"} for k, v in scores.items()},
            "status": "Verification required" if policy["verification_required"] else "Reviewed",
            "history": [],
            "audio": fixture["audio"],
            "duration": len(fixture["progression"]) * 3,
        }
    )


def process(data, transcript, identity, workflow, retain_transcript):
    samples, sr = decode(data)
    prosody = analyze_prosody(samples, sr)
    context = (
        analyze_context(transcript)
        if transcript.strip()
        else {"score": None, "signals": [], "source": "UNAVAILABLE"}
    )
    metrics = {
        "speaker": {"score": None, "source": "NOT_CONFIGURED"},
        "prosody": prosody,
        "context": {"score": context["score"], "source": context["source"]},
    }
    timeline, segments = [], []
    total = len(samples)
    # Independent 5-second windows. A final tail shorter than 1 second joins the last window.
    starts = list(range(0, total, sr * 5))
    if len(starts) > 1 and total - starts[-1] < sr:
        starts.pop()
    try:
        for index, start in enumerate(starts):
            end = starts[index + 1] if index + 1 < len(starts) else total
            result = detector.detect(samples[start:end], sr)
            segments.append(result)
            timeline.append(
                fuse(
                    {
                        "synthetic": result["score"],
                        "speaker": None,
                        "prosody": prosody["score"],
                        "context": context["score"],
                    }
                )["score"]
            )
        synthetic = dict(segments[-1])
        synthetic["score"] = round(sum(x["score"] for x in segments) / len(segments), 2)
        synthetic["synthetic_probability"] = synthetic["score"] / 100
        synthetic["models"] = [
            {"model": detector.model, "synthetic_probability": synthetic["synthetic_probability"]}
        ]
        synthetic["latency_ms"] = sum(x["latency_ms"] for x in segments)
        synthetic["aggregation"] = "mean_of_chunks"
        metrics["synthetic"] = synthetic
    except RuntimeError:
        raise HTTPException(
            503,
            "Voice engine unavailable. Retry after initialization or use the clearly labeled presentation demo.",
        )
    risk = fuse({k: v["score"] for k, v in metrics.items()})
    policy = evaluate(risk["score"], workflow, storage.settings(), True, context["signals"])
    # The transcript is user supplied, not speech recognition. Context is clip-level, not word-time aligned.
    return storage.save(
        {
            "id": "INC-" + uuid.uuid4().hex[:8].upper(),
            "created": storage.now(),
            "mode": "REAL_ANALYSIS",
            "identity": identity,
            "transcript": transcript if retain_transcript else "",
            "transcript_source": "USER_SUPPLIED" if transcript else "UNAVAILABLE",
            "risk": risk,
            "policy": policy,
            "timeline": timeline,
            "metrics": metrics,
            "signals": context["signals"]
            if retain_transcript
            else [{k: v for k, v in s.items() if k != "matches"} for s in context["signals"]],
            "status": "Verification required" if policy["verification_required"] else "Reviewed",
            "history": [],
            "waveform": peaks(samples),
            "duration": round(total / sr, 2),
            "raw_audio_retained": False,
            "limitations": [
                "Single detector; uncalibrated model score.",
                "Speaker verification unavailable.",
                "Context is from an optional user-supplied transcript and is applied to all chunks.",
            ],
        }
    )


@app.post("/api/analyze", status_code=201)
@app.post("/api/analyze/chunk", status_code=201)
async def analyze(
    file: UploadFile = File(...),
    transcript: str = Form("", max_length=10000),
    identity: str = Form("Unknown caller", max_length=120),
    workflow: Literal["normal", "payment", "privileged"] = Form("payment"),
    retain_transcript: bool = Form(False),
):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in {".wav", ".flac"} or file.content_type not in {
        "audio/wav",
        "audio/x-wav",
        "audio/wave",
        "audio/flac",
        "audio/x-flac",
        "application/octet-stream",
    }:
        raise HTTPException(415, "Use a WAV or FLAC audio file.")
    if analysis_gate.locked():
        raise HTTPException(429, "Another call is being analyzed. Please retry shortly.")
    async with analysis_gate:
        data = await file.read(MAX_BYTES + 1)
        await file.close()
        if len(data) > MAX_BYTES:
            raise HTTPException(413, "Audio exceeds the 20 MB limit.")
        try:
            return await run_in_threadpool(process, data, transcript, identity, workflow, retain_transcript)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc


@app.get("/api/incidents")
def incidents():
    return storage.list_incidents()


@app.get("/api/incidents/{incident_id}")
def incident(incident_id: str):
    record = storage.get(incident_id)
    if not record:
        raise HTTPException(404, "Incident not found.")
    return record


class Action(BaseModel):
    action: Literal[
        "Callback requested", "MFA requested", "Escalated to supervisor", "Verification completed"
    ]
    note: str = Field(default="", max_length=500)


@app.patch("/api/incidents/{incident_id}")
def record_action(incident_id: str, action: Action):
    record = incident(incident_id)
    record["history"].append({"at": storage.now(), **action.model_dump()})
    record["status"] = "Verification recorded" if action.action == "Verification completed" else action.action
    return storage.save(record)


class Settings(BaseModel):
    normal: int = Field(75, ge=1, le=100)
    payment: int = Field(45, ge=1, le=100)
    privileged: int = Field(40, ge=1, le=100)


@app.get("/api/settings")
def get_settings():
    return storage.settings()


@app.put("/api/settings")
def put_settings(settings: Settings):
    return storage.settings(settings.model_dump())


# Same-origin production build. API routes are registered first.
@app.get("/{path:path}", include_in_schema=False)
def frontend(path: str):
    if path.startswith("api/"):
        raise HTTPException(404, "API route not found.")
    dist = ROOT / "frontend/dist"
    candidate = (dist / path).resolve()
    if not candidate.is_relative_to(dist.resolve()):
        raise HTTPException(404)
    if candidate.is_file():
        return FileResponse(candidate)
    if (dist / "index.html").exists():
        return FileResponse(dist / "index.html")
    raise HTTPException(404, "Build frontend or start Vite on port 5173.")
