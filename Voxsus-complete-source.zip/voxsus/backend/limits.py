"""Bound request bodies before multipart parsing, including chunked transport."""
from starlette.exceptions import HTTPException
from starlette.responses import JSONResponse


class BodyLimitMiddleware:
    def __init__(self, app, max_bytes=21 * 1024 * 1024):
        self.app = app
        self.max_bytes = max_bytes

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            return await self.app(scope, receive, send)
        length = dict(scope.get('headers', [])).get(b'content-length', b'0')
        try:
            oversized = int(length) > self.max_bytes
        except ValueError:
            oversized = True
        if oversized:
            return await JSONResponse({'detail': 'Request exceeds the upload limit.'}, status_code=413)(scope, receive, send)
        total = 0

        async def limited_receive():
            nonlocal total
            message = await receive()
            total += len(message.get('body', b''))
            if total > self.max_bytes:
                raise HTTPException(413, 'Request exceeds the upload limit.')
            return message

        return await self.app(scope, limited_receive, send)
