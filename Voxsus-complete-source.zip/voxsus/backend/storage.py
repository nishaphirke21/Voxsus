import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DEFAULTS = {"normal": 75, "payment": 45, "privileged": 40}


def connect():
    path = Path(os.getenv("VOXSUS_DB", str(Path(__file__).resolve().parents[1] / "database/voxsus.db")))
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path, timeout=10)
    db.execute(
        "CREATE TABLE IF NOT EXISTS incidents (id TEXT PRIMARY KEY, created TEXT, payload TEXT NOT NULL)"
    )
    db.execute("CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY, payload TEXT NOT NULL)")
    return db


def save(record):
    with connect() as db:
        db.execute(
            "INSERT INTO incidents VALUES (?, ?, ?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload",
            (record["id"], record["created"], json.dumps(record)),
        )
    return record


def get(incident_id):
    with connect() as db:
        row = db.execute("SELECT payload FROM incidents WHERE id=?", (incident_id,)).fetchone()
    return json.loads(row[0]) if row else None


def list_incidents():
    with connect() as db:
        rows = db.execute("SELECT payload FROM incidents ORDER BY created DESC LIMIT 200").fetchall()
    return [json.loads(row[0]) for row in rows]


def settings(value=None):
    with connect() as db:
        if value is not None:
            db.execute(
                "INSERT INTO settings VALUES (1, ?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload",
                (json.dumps(value),),
            )
        row = db.execute("SELECT payload FROM settings WHERE id=1").fetchone()
    return json.loads(row[0]) if row else DEFAULTS.copy()


def now():
    return datetime.now(timezone.utc).isoformat()
