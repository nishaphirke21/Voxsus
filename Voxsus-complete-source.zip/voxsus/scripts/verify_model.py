"""Run actual inference on two externally labeled upstream samples; no accuracy claim."""

import json
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from analysis.audio import decode  # noqa: E402
from analysis.synthetic_detector import detector  # noqa: E402

COMMIT = "093999df92dd3f37e514d8b87dc96fb38def802e"
target = ROOT / "samples/validation"
target.mkdir(parents=True, exist_ok=True)
results = []
for label in ("bonafide", "spoof"):
    name = f"{label}.flac"
    source = f"https://raw.githubusercontent.com/MattyB95/Jabberjay/{COMMIT}/res/{label}/{name}"
    path = target / name
    if not path.exists():
        urllib.request.urlretrieve(source, path)
    samples, sr = decode(path.read_bytes())
    start = time.perf_counter()
    result = detector.detect(samples, sr)
    entry = {
        "sample": name,
        "upstream_label": label,
        "sample_url": source,
        "duration": len(samples) / sr,
        "wall_seconds": round(time.perf_counter() - start, 3),
        **result,
    }
    results.append(entry)
    print(json.dumps(entry), flush=True)
(ROOT / f"docs/validation-{detector.model.lower()}.json").write_text(
    json.dumps(results, indent=2), encoding="utf-8"
)
