import numpy as np


def analyze_prosody(samples: np.ndarray, sr: int) -> dict:
    """Interpretable energy/pause heuristic; no learned authenticity claim."""
    size = int(sr * 0.025)
    frames = samples[: len(samples) // size * size].reshape(-1, size)
    rms = np.sqrt(np.mean(frames**2, axis=1))
    variation = float(np.std(rms) / (np.mean(rms) + 1e-8))
    pauses = float(np.mean(rms < max(float(np.max(rms)) * 0.08, 0.002)))
    score = round(min(100, max(0, (0.5 - variation) * 90) + max(0, pauses - 0.45) * 60))
    return {
        "score": score,
        "source": "HEURISTIC",
        "energy_variation": round(variation, 3),
        "pause_fraction": round(pauses, 3),
        "limitation": "Energy and silence can reflect compression, delivery or noise; not proof of synthesis.",
    }
