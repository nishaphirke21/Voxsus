"""English lexical rules; separate from acoustic model evidence."""

import re

RULES = [
    (
        "high_value_transfer",
        r"(?:₹\s*[\d,.]+\s*(?:lakh|crore)?|\b\d+(?:\.\d+)?\s*(?:lakh|crore|million)\b)",
        35,
        "high",
        "Large amount mentioned; validate the beneficiary and approval path.",
    ),
    (
        "payment_request",
        r"\b(?:transfer|approve (?:this |the )?payment|wire (?:money|funds)|send money)\b",
        25,
        "high",
        "A financial instruction raises the impact of mistaken identity.",
    ),
    (
        "credential_request",
        r"\b(?:otp|password|passcode|credentials|verification code)\b",
        55,
        "high",
        "Never disclose authentication secrets on the strength of a voice.",
    ),
    (
        "urgency",
        r"\b(?:immediately|urgent(?:ly)?|right now|do it now|emergency)\b",
        18,
        "medium",
        "Time pressure can discourage careful checks.",
    ),
    (
        "anti_verification",
        r"(?:don['’]?t|do not)\s+(?:call(?: me)? back|verify|check)",
        35,
        "high",
        "Discouraging independent verification is a strong warning.",
    ),
    (
        "secrecy",
        r"\b(?:keep (?:this |it )?confidential|don['’]?t tell anyone|do not tell anyone|keep (?:this |it )?secret)\b",
        20,
        "high",
        "Secrecy can isolate the recipient from normal approval controls.",
    ),
    (
        "authority",
        r"\b(?:i am|i'm) (?:the |your )?(?:ceo|cfo|director|boss)\b",
        10,
        "medium",
        "Claimed authority is not independently verified identity.",
    ),
]


def analyze_context(transcript: str) -> dict:
    signals = []
    for kind, pattern, weight, severity, explanation in RULES:
        matches = list(re.finditer(pattern, transcript, re.IGNORECASE))
        if matches:
            signals.append(
                {
                    "type": kind,
                    "weight": weight,
                    "severity": severity,
                    "explanation": explanation,
                    "matches": [{"start": m.start(), "end": m.end(), "text": m.group()} for m in matches],
                }
            )
    return {
        "score": min(100, sum(s["weight"] for s in signals)),
        "signals": signals,
        "source": "RULE_BASED",
        "language": "en",
        "limitation": "Lexical rules can flag quotations or negations; review context manually.",
    }
