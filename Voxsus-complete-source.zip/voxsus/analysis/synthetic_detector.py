"""Jabberjay adapter. Never substitutes fixture scores on failure."""

import os
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("HF_HOME", str(ROOT / ".cache" / "huggingface"))
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".cache" / "matplotlib"))
os.environ.setdefault("NUMBA_CACHE_DIR", str(ROOT / ".cache" / "numba"))


class SyntheticDetector:
    def __init__(self):
        self.model = os.getenv("VOXSUS_MODEL", "HuBERT")
        self.state = "not_loaded"
        self.error = None
        self._engine = None
        self._lock = threading.Lock()

    def detect(self, samples, sr: int) -> dict:
        with self._lock:
            try:
                if self._engine is None:
                    self.state = "initializing"
                    import torch
                    from Jabberjay import Jabberjay

                    torch.set_num_threads(min(4, os.cpu_count() or 1))
                    self._engine = Jabberjay()
                start = time.perf_counter()
                result = self._engine.detect((samples, sr), model=self.model)
                if result.scores:
                    spoof = next(float(x["score"]) for x in result.scores if x["label"] == "Spoof")
                else:
                    spoof = 1 - result.confidence if result.is_bonafide else result.confidence
                if not 0 <= spoof <= 1:
                    raise ValueError("Invalid model probability")
                self.state, self.error = "ready", None
                return {
                    "source": "REAL_MODEL",
                    "provider": "jabberjay",
                    "model": self.model,
                    "score": round(spoof * 100, 2),
                    "synthetic_probability": spoof,
                    "latency_ms": round((time.perf_counter() - start) * 1000),
                    "models": [{"model": self.model, "synthetic_probability": spoof}],
                    "consensus_count": 1,
                }
            except Exception as exc:
                self.state = "unavailable"
                self.error = type(exc).__name__
                raise RuntimeError(
                    "Voice engine unavailable. Check model installation/download and retry."
                ) from exc

    def warmup(self):
        import numpy as np

        try:
            self.detect(np.zeros(32000, dtype=np.float32), 16000)
        except RuntimeError:
            pass

    def health(self) -> dict:
        return {"state": self.state, "model": self.model, "provider": "jabberjay", "error": self.error}


detector = SyntheticDetector()
