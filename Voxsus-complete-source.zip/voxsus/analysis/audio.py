import io
import math

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

MAX_BYTES = 20 * 1024 * 1024


def decode(data: bytes) -> tuple[np.ndarray, int]:
    try:
        with sf.SoundFile(io.BytesIO(data)) as stream:
            duration = len(stream) / stream.samplerate
            if not 1 <= duration <= 60:
                raise ValueError("Choose audio between 1 and 60 seconds.")
            if stream.channels > 2 or not 8000 <= stream.samplerate <= 96000:
                raise ValueError("Use mono or stereo audio at 8–96 kHz.")
            samples = stream.read(dtype="float32", always_2d=True).mean(axis=1)
            sr = stream.samplerate
    except (RuntimeError, sf.LibsndfileError) as exc:
        raise ValueError("This audio could not be decoded. Export a PCM WAV or FLAC file.") from exc
    if not np.isfinite(samples).all() or float(np.max(np.abs(samples))) < 0.0001:
        raise ValueError("No usable audio detected. Try a clear spoken recording.")
    if sr != 16000:
        divisor = math.gcd(sr, 16000)
        samples = resample_poly(samples, 16000 // divisor, sr // divisor).astype(np.float32)
    return samples, 16000


def peaks(samples: np.ndarray, count: int = 96) -> list[float]:
    result = [float(np.sqrt(np.mean(chunk**2))) for chunk in np.array_split(samples, count)]
    maximum = max(result) or 1
    return [round(x / maximum, 3) for x in result]
