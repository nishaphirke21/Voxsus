export type Workflow = "normal" | "payment" | "privileged";
export type Signal = {
  type: string;
  severity: string;
  explanation: string;
  matches?: { start: number; end: number; text: string }[];
};
export type Metric = {
  score: number | null;
  source: string;
  model?: string;
  provider?: string;
  latency_ms?: number;
  energy_variation?: number;
  pause_fraction?: number;
};
export type Incident = {
  id: string;
  created: string;
  mode: "DEMO_ANALYSIS" | "REAL_ANALYSIS";
  identity: string;
  transcript: string;
  transcript_source: string;
  status: string;
  duration: number;
  audio?: string;
  waveform?: number[];
  timeline: number[];
  metrics: Record<string, Metric>;
  signals: Signal[];
  risk: { score: number; level: string; coverage: number; missing: string[] };
  policy: {
    threshold: number;
    workflow: Workflow;
    verification_required: boolean;
    recommendation: string;
    reason: string;
    enforced: boolean;
  };
  history: { at: string; action: string; note: string }[];
};
export type Health = {
  synthetic: { state: string; model: string; error?: string };
  speaker: string;
  transcription: string;
};
