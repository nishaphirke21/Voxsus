import { useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  ArrowUpRight,
  AudioLines,
  Check,
  FileAudio,
  Mic,
  Pause,
  Play,
  RotateCcw,
  Upload,
  Volume2,
  X,
} from "lucide-react";
import scenarios from "../../samples/scenarios.json";
import { api, saveLocalDemo } from "./api";
import {
  AppShell,
  Badge,
  ErrorNotice,
  Metrics,
  RiskChart,
  Source,
  Transcript,
  Waveform,
} from "./components";
import type { Health, Incident, Workflow } from "./types";

function fallbackDemo(index: number, workflow: Workflow): Incident {
  const s = scenarios[index];
  return {
    id: `LOCAL-DEMO-${Date.now()}`,
    created: new Date().toISOString(),
    mode: "DEMO_ANALYSIS",
    identity: s.identity,
    transcript: s.transcript,
    transcript_source: "SCRIPTED_SCENARIO",
    status: index ? "Verification required" : "Reviewed",
    duration: s.progression.length * 3,
    audio: s.audio,
    timeline: s.progression,
    risk: {
      score: s.progression.at(-1)!,
      level: index ? "CRITICAL" : "LOW",
      coverage: 100,
      missing: [],
    },
    metrics: Object.fromEntries(
      ["synthetic", "speaker", "prosody", "context"].map((k) => [
        k,
        { score: s[k as "synthetic"], source: "DEMO" },
      ]),
    ),
    signals: [],
    policy: {
      workflow,
      threshold: workflow === "normal" ? 75 : workflow === "payment" ? 45 : 40,
      verification_required: !!index,
      recommendation: index
        ? "Pause sensitive action. Verify through a registered callback, MFA or supervisor."
        : "Continue with normal verification procedures.",
      reason:
        "Scripted presentation scenario. Default policy; backend unavailable.",
      enforced: false,
    },
    history: [],
  };
}

export default function Demo() {
  const [params] = useSearchParams();
  const [mode, setMode] = useState(
    params.get("scenario") === "genuine" ? 0 : 1,
  );
  const [running, setRunning] = useState(false);
  const [step, setStep] = useState(-1);
  const [result, setResult] = useState<Incident | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [workflow, setWorkflow] = useState<Workflow>("payment");
  const [health, setHealth] = useState<Health | null>(null);
  const [busy, setBusy] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [transcript, setTranscript] = useState("");
  const [identity, setIdentity] = useState("");
  const [retain, setRetain] = useState(false);
  const [recording, setRecording] = useState(false);
  const [audioURL, setAudioURL] = useState("");
  const [realPeaks, setRealPeaks] = useState<number[]>();
  const [audioProgress, setAudioProgress] = useState(0);
  const [audioPlaying, setAudioPlaying] = useState(false);
  const audio = useRef<HTMLAudioElement>(null);
  const recorder = useRef<{
    context: AudioContext;
    source: MediaStreamAudioSourceNode;
    processor: ScriptProcessorNode;
    stream: MediaStream;
    chunks: Float32Array[];
    timer: number;
  } | null>(null);
  const token = useRef(0);
  const scenario = scenarios[Math.min(mode, 1)];
  const timeline =
    mode < 2 ? scenario.progression.slice(0, step + 1) : result?.timeline || [];
  const score = mode < 2 ? timeline.at(-1) || 0 : result?.risk.score || 0;
  const complete =
    mode < 2 ? step === scenario.progression.length - 1 : !!result;
  useEffect(() => {
    let active = true;
    const poll = () =>
      api<Health>("/health")
        .then((v) => {
          if (active) setHealth(v);
        })
        .catch(() => {
          if (active) setHealth(null);
        });
    poll();
    const timer = window.setInterval(poll, 7000);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, []);
  useEffect(() => {
    if (!running || mode > 1) return;
    const timer = window.setTimeout(() => {
      setStep((s) => s + 1);
      if (step + 1 >= scenario.progression.length - 1) setRunning(false);
    }, 1800);
    return () => clearTimeout(timer);
  }, [running, step, mode, scenario.progression.length]);
  useEffect(() => {
    if (!file) {
      setAudioURL("");
      setRealPeaks(undefined);
      return;
    }
    const url = URL.createObjectURL(file);
    setAudioURL(url);
    let active = true;
    const context = new AudioContext();
    file
      .arrayBuffer()
      .then((b) => context.decodeAudioData(b))
      .then((b) => {
        const samples = b.getChannelData(0);
        const stride = Math.max(1, Math.floor(samples.length / 96));
        const peaks = Array.from({ length: 96 }, (_, i) => {
          let sum = 0;
          for (
            let j = i * stride;
            j < Math.min((i + 1) * stride, samples.length);
            j++
          )
            sum += samples[j] ** 2;
          return Math.sqrt(sum / stride);
        });
        const max = Math.max(...peaks) || 1;
        if (active) setRealPeaks(peaks.map((p) => p / max));
      })
      .catch(() => {})
      .finally(() => context.close());
    return () => {
      active = false;
      URL.revokeObjectURL(url);
    };
  }, [file]);
  useEffect(
    () => () => {
      token.current++;
      const r = recorder.current;
      if (r) {
        clearTimeout(r.timer);
        r.stream.getTracks().forEach((t) => t.stop());
        r.processor.disconnect();
        r.source.disconnect();
        void r.context.close();
      }
    },
    [],
  );
  function changeMode(value: number) {
    token.current++;
    setMode(value);
    setRunning(false);
    setStep(-1);
    setResult(null);
    setError("");
    setNotice("");
    audio.current?.pause();
    setAudioProgress(0);
  }
  async function start() {
    setError("");
    setNotice("");
    setStep(-1);
    setRunning(true);
    const run = ++token.current;
    const fallback = fallbackDemo(mode, workflow);
    setResult(fallback);
    try {
      const item = await api<Incident>("/demo", {
        method: "POST",
        body: JSON.stringify({ scenario: scenario.id, workflow }),
      });
      if (run === token.current) setResult(item);
    } catch {
      if (run !== token.current) return;
      saveLocalDemo(fallback);
      setNotice(
        "Presentation continues offline. This demo record is saved only in this browser.",
      );
    }
  }
  function chooseFile(f?: File) {
    setError("");
    setResult(null);
    if (!f) return;
    if (!/\.(wav|flac)$/i.test(f.name)) {
      setError(
        "Choose a WAV or FLAC recording. Other formats are not supported yet.",
      );
      return;
    }
    if (f.size > 20 * 1024 * 1024) {
      setError("Choose a file smaller than 20 MB.");
      return;
    }
    setFile(f);
  }
  async function analyze() {
    if (!file) return;
    setBusy(true);
    setError("");
    setResult(null);
    const data = new FormData();
    data.append("file", file);
    data.append("transcript", transcript);
    data.append("identity", identity || "Unknown caller");
    data.append("workflow", workflow);
    data.append("retain_transcript", String(retain));
    try {
      setResult(
        await api<Incident>("/analyze", { method: "POST", body: data }),
      );
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "Backend offline. Start the local server and try again.",
      );
    } finally {
      setBusy(false);
    }
  }
  async function toggleAudio() {
    const el = audio.current;
    if (!el) return;
    if (el.paused) {
      try {
        await el.play();
      } catch {
        setError(
          "Audio playback is unavailable. You can continue the visual assessment.",
        );
      }
    } else el.pause();
  }
  async function startRecording() {
    setError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const context = new AudioContext();
      const source = context.createMediaStreamSource(stream);
      const processor = context.createScriptProcessor(4096, 1, 1);
      const chunks: Float32Array[] = [];
      processor.onaudioprocess = (e) =>
        chunks.push(new Float32Array(e.inputBuffer.getChannelData(0)));
      source.connect(processor);
      processor.connect(context.destination);
      const timer = window.setTimeout(() => stopRecording(), 30000);
      recorder.current = { context, source, processor, stream, chunks, timer };
      setRecording(true);
    } catch {
      setError(
        "Microphone access was denied or unavailable. Allow access in your browser, or upload a recording.",
      );
    }
  }
  function stopRecording() {
    const r = recorder.current;
    if (!r) return;
    clearTimeout(r.timer);
    r.processor.disconnect();
    r.source.disconnect();
    r.stream.getTracks().forEach((t) => t.stop());
    const length = r.chunks.reduce((n, c) => n + c.length, 0);
    const buffer = new ArrayBuffer(44 + length * 2);
    const view = new DataView(buffer);
    const write = (offset: number, s: string) =>
      [...s].forEach((c, i) => view.setUint8(offset + i, c.charCodeAt(0)));
    write(0, "RIFF");
    view.setUint32(4, 36 + length * 2, true);
    write(8, "WAVEfmt ");
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, r.context.sampleRate, true);
    view.setUint32(28, r.context.sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    write(36, "data");
    view.setUint32(40, length * 2, true);
    let offset = 44;
    r.chunks.forEach((chunk) =>
      chunk.forEach((value) => {
        view.setInt16(offset, Math.max(-1, Math.min(1, value)) * 32767, true);
        offset += 2;
      }),
    );
    void r.context.close();
    recorder.current = null;
    setRecording(false);
    chooseFile(new File([buffer], "microphone.wav", { type: "audio/wav" }));
  }
  const level =
    score >= 80
      ? "CRITICAL"
      : score >= 60
        ? "HIGH"
        : score >= 30
          ? "CAUTION"
          : "LOW";
  return (
    <AppShell>
      <div className="page-heading">
        <div>
          <span className="eyebrow">THE LISTENING ROOM</span>
          <h1>
            let’s listen deeper<span className="accent">.</span>
          </h1>
          <p>A voice, a request, and the evidence between them.</p>
        </div>
        <span className="engine-state">
          <i
            className={`status-dot ${health?.synthetic.state === "ready" ? "" : "amber"}`}
          />
          {health
            ? health.synthetic.state === "ready"
              ? "voice engine ready"
              : health.synthetic.state === "initializing"
                ? "initializing voice engine"
                : `engine ${health.synthetic.state}`
            : "backend offline"}
        </span>
      </div>
      <div className="demo-controls">
        <div className="segmented" role="tablist" aria-label="Analysis mode">
          {["Genuine call", "Cloned call", "Upload audio"].map((name, i) => (
            <button
              key={name}
              role="tab"
              aria-selected={mode === i}
              onClick={() => changeMode(i)}
              disabled={busy || recording}
            >
              {i === 2 ? <Upload size={16} /> : <AudioLines size={16} />} {name}
            </button>
          ))}
        </div>
        <label className="workflow-label">
          Workflow
          <select
            value={workflow}
            disabled={running || busy}
            onChange={(e) => setWorkflow(e.target.value as Workflow)}
          >
            <option value="normal">Everyday call</option>
            <option value="payment">Payment approval</option>
            <option value="privileged">Privileged access</option>
          </select>
        </label>
      </div>
      {error && <ErrorNotice message={error} />}{" "}
      {notice && <div className="notice">{notice}</div>}
      <div className="demo-grid">
        <div className="demo-main">
          <section className="panel audio-panel">
            <div className="panel-heading">
              <span>
                <i className="status-dot" />{" "}
                {mode < 2 ? "PRESENTATION MODE" : "REAL AUDIO ANALYSIS"}
              </span>
              <Source value={mode < 2 ? "DEMO_ANALYSIS" : "REAL_ANALYSIS"} />
            </div>
            <div className="call-title">
              <span className="caller-avatar">
                {mode < 2 ? "VX" : <FileAudio size={22} />}
              </span>
              <div>
                <h2>
                  {mode < 2
                    ? scenario.title
                    : file?.name || "drop a call here."}
                </h2>
                <p>
                  {mode < 2
                    ? scenario.identity
                    : "WAV / FLAC · 1–60 seconds · up to 20 MB"}
                </p>
              </div>
            </div>
            {mode === 2 && (
              <>
                <label
                  className={`dropzone ${file ? "has-file" : ""}`}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    chooseFile(e.dataTransfer.files[0]);
                  }}
                >
                  <Upload size={25} />
                  <strong>
                    {file
                      ? "choose another recording"
                      : "drop a recording, or browse"}
                  </strong>
                  <small>
                    Processed locally by your Voxsus backend. Raw audio isn’t
                    saved.
                  </small>
                  <input
                    type="file"
                    accept=".wav,.flac,audio/wav,audio/flac"
                    aria-label="Upload WAV or FLAC audio"
                    onChange={(e) => chooseFile(e.target.files?.[0])}
                    disabled={busy || recording}
                  />
                </label>
                <div className="record-row">
                  <button
                    className={`button secondary small ${recording ? "recording" : ""}`}
                    onClick={recording ? stopRecording : startRecording}
                    disabled={busy}
                  >
                    {recording ? <Pause size={15} /> : <Mic size={15} />}{" "}
                    {recording ? "stop recording" : "record your voice"}
                  </button>
                  <small>
                    {recording
                      ? "Recording · stops after 30 seconds"
                      : "microphone stays off until you choose to record"}
                  </small>
                </div>
                <div className="input-grid">
                  <label>
                    Claimed identity
                    <input
                      value={identity}
                      maxLength={120}
                      onChange={(e) => setIdentity(e.target.value)}
                      placeholder="e.g. finance director"
                    />
                  </label>
                  <label>
                    Transcript{" "}
                    <span className="muted">(optional, supplied by you)</span>
                    <textarea
                      value={transcript}
                      onChange={(e) => setTranscript(e.target.value)}
                      maxLength={10000}
                      placeholder="Paste what was said to add contextual analysis."
                      rows={3}
                    />
                  </label>
                </div>
                <label className="checkbox">
                  <input
                    type="checkbox"
                    checked={retain}
                    onChange={(e) => setRetain(e.target.checked)}
                  />{" "}
                  Save this transcript in the incident history
                </label>
              </>
            )}
            <Waveform
              active={running || audioPlaying || recording}
              peaks={mode === 2 ? realPeaks : undefined}
              progress={audioProgress}
            />
            <div className="audio-controls">
              <button
                className="icon-button"
                aria-label={
                  audioPlaying
                    ? "Pause audio"
                    : "Play scenario narration or uploaded audio"
                }
                onClick={toggleAudio}
                disabled={mode === 2 && !file}
              >
                {audioPlaying ? <Pause size={19} /> : <Volume2 size={19} />}
              </button>
              <span>
                {mode < 2
                  ? "computer-generated scenario narration"
                  : "your recording · local playback"}
              </span>
              {mode < 2 ? (
                <button
                  className="button primary small"
                  onClick={
                    running
                      ? () => setRunning(false)
                      : step >= 0 && !complete
                        ? () => setRunning(true)
                        : start
                  }
                  data-cursor="scan"
                >
                  {running ? (
                    <Pause size={15} />
                  ) : complete ? (
                    <RotateCcw size={15} />
                  ) : (
                    <Play size={15} />
                  )}{" "}
                  {running
                    ? "pause"
                    : complete
                      ? "replay assessment"
                      : step >= 0
                        ? "resume"
                        : "run scenario"}
                </button>
              ) : (
                <button
                  className="button primary small"
                  disabled={!file || busy || recording}
                  onClick={analyze}
                >
                  {busy ? <AudioLines size={17} /> : <ScanIcon />}
                  {busy ? "analyzing voice…" : "analyze recording"}
                </button>
              )}
            </div>
            <audio
              ref={audio}
              src={mode < 2 ? scenario.audio : audioURL || undefined}
              onPlay={() => setAudioPlaying(true)}
              onPause={() => setAudioPlaying(false)}
              onEnded={() => setAudioPlaying(false)}
              onTimeUpdate={() => {
                const a = audio.current;
                if (a && a.duration)
                  setAudioProgress(a.currentTime / a.duration);
              }}
            />
            {mode < 2 ? (
              <div className="disclosure">
                Simulated scores and scripted risk progression. Both audio
                tracks are computer-generated narration, not a genuine/cloned
                comparison. Upload audio for actual model inference.
              </div>
            ) : (
              <div className="disclosure">
                One real HuBERT detector · 5-second windows · English context
                rules. Speaker verification and automatic transcription are not
                configured.
              </div>
            )}
            {busy && (
              <div className="analysis-progress" role="status">
                <span className="pulse-dot" /> Preparing audio → analyzing voice
                → assessing context → applying policy. First inference may take
                longer while weights load.
              </div>
            )}
          </section>
          <section className="panel timeline-panel">
            <div className="panel-heading">
              <h2>risk, as it unfolds.</h2>
              <span>
                {mode < 2 ? "SCRIPTED SEQUENCE" : "MEASURED AUDIO WINDOWS"}
              </span>
            </div>
            <RiskChart
              values={timeline}
              threshold={result?.policy.threshold || 45}
            />
            <div className="chart-foot">
              <span>
                {mode < 2
                  ? `${Math.max(0, step + 1)} / ${scenario.progression.length} assessment moments`
                  : `${timeline.length} analyzed chunks`}
              </span>
              <span>risk index / 100</span>
            </div>
          </section>
          <section className="panel">
            <div className="panel-heading">
              <h2>what’s being said.</h2>
              <Source value={mode < 2 ? "SCRIPTED" : "USER_SUPPLIED"} />
            </div>
            <Transcript
              text={mode < 2 ? scenario.transcript : transcript}
              signals={result?.signals}
            />
            <div className="signal-chips">
              {(result?.signals.length
                ? result.signals.map((s) => s.type.replaceAll("_", " "))
                : mode < 2
                  ? scenario.signals
                  : []
              ).map((s) => (
                <span key={s}>{s}</span>
              ))}
            </div>
          </section>
        </div>
        <aside className="demo-aside">
          <section className={`panel risk-panel ${level.toLowerCase()}`}>
            <div className="panel-heading">
              <span>OVERALL RISK</span>
              <AudioLines size={18} />
            </div>
            <div className="risk-number" aria-live="polite">
              {timeline.length ? score : "—"}
              <span>/100</span>
            </div>
            <Badge level={timeline.length ? level : "UNKNOWN"}>
              {timeline.length ? level : "AWAITING AUDIO"}
            </Badge>
            <p>
              {timeline.length
                ? score >= 60
                  ? "The request deserves a second check."
                  : "Keep listening. Keep verification in place."
                : "A little evidence goes a long way."}
            </p>
            <div className="risk-breakdown">
              <span>Signal coverage</span>
              <b>{result ? `${result.risk.coverage}%` : "—"}</b>
            </div>
            {result?.risk.missing.length ? (
              <small>
                Unavailable: {result.risk.missing.join(", ")}. Weights
                normalized over available evidence.
              </small>
            ) : (
              <small>
                {mode < 2
                  ? "All displayed signal scores are simulated."
                  : "Missing signals will be shown explicitly."}
              </small>
            )}
          </section>
          <section className="panel">
            <div className="panel-heading">
              <h2>the evidence.</h2>
            </div>
            <Metrics
              metrics={
                result && (step >= 0 || mode === 2) ? result.metrics : {}
              }
            />
          </section>
          <section
            className={`recommendation ${complete && result?.policy.verification_required ? "requires-check" : ""}`}
          >
            <div className="panel-heading">
              <span>RECOMMENDED NEXT STEP</span>
              <ArrowUpRight size={18} />
            </div>
            <h3>
              {complete
                ? result?.policy.verification_required
                  ? "pause. verify. proceed."
                  : "normal checks still matter."
                : "listen before you decide."}
            </h3>
            <p>
              {complete
                ? result?.policy.recommendation
                : "Finish an assessment to see the policy recommendation."}
            </p>
            {complete && result && (
              <>
                <Link
                  to={`/incidents/${result.id}`}
                  className="button dark small"
                >
                  open incident <ArrowUpRight size={16} />
                </Link>
                <small>
                  Recommendations only. No transaction is automatically blocked.
                </small>
              </>
            )}
          </section>
        </aside>
      </div>
      <div className="demo-bottom-note">
        <Check size={16} /> Model probability isn’t proof. The risk index is an
        uncalibrated prototype score.
      </div>
    </AppShell>
  );
}
function ScanIcon() {
  return (
    <span aria-hidden="true">
      <X size={15} style={{ transform: "rotate(45deg)" }} />
    </span>
  );
}
