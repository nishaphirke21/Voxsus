import React from "react";
import ReactDOM from "react-dom/client";
import {
  BrowserRouter,
  Route,
  Routes,
  useLocation,
  Link,
} from "react-router-dom";
import { useEffect } from "react";
import "@fontsource/dm-sans/latin-400.css";
import "@fontsource/dm-sans/latin-500.css";
import "@fontsource/dm-sans/latin-600.css";
import "@fontsource/dm-sans/latin-700.css";
import "@fontsource/manrope/latin-400.css";
import "@fontsource/manrope/latin-500.css";
import "@fontsource/manrope/latin-600.css";
import "@fontsource/manrope/latin-700.css";
import Home from "./Home";
import Demo from "./Demo";
import {
  Architecture,
  Console,
  IncidentDetail,
  Incidents,
  Settings,
  VoiceProfiles,
} from "./Console";
import { Cursor } from "./components";
import "./styles.css";
function ScrollReset() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}
function App() {
  return (
    <BrowserRouter>
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>
      <ScrollReset />
      <Cursor />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/demo" element={<Demo />} />
        <Route path="/console" element={<Console />} />
        <Route path="/incidents" element={<Incidents />} />
        <Route path="/incidents/:id" element={<IncidentDetail />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/voice-profiles" element={<VoiceProfiles />} />
        <Route path="/architecture" element={<Architecture />} />
        <Route
          path="*"
          element={
            <main id="main-content" className="empty-state">
              <h1>this signal went quiet.</h1>
              <p>The page you’re looking for doesn’t exist.</p>
              <Link to="/" className="button primary">
                Back to Voxsus
              </Link>
            </main>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
