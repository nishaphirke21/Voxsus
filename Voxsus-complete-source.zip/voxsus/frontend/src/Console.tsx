import { useCallback, useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  ArrowLeft,
  ArrowUpRight,
  AudioLines,
  Check,
  Clock,
  Download,
  FileAudio,
  Phone,
  Search,
  Settings2,
  Users,
  Activity,
  GitBranch,
} from "lucide-react";
import { api, allIncidents, localDemos, saveLocalDemo } from "./api";
import {
  AppShell,
  ArchitectureGraphic,
  Badge,
  ErrorNotice,
  Metrics,
  RiskChart,
  Source,
  Transcript,
  Waveform,
} from "./components";
import type { Health, Incident } from "./types";

function useIncidents() {
  const [items, setItems] = useState<Incident[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(() => {
    setLoading(true);
    allIncidents()
      .then((x) => {
        setItems(x);
        setError("");
      })
      .catch(() => {
        setItems(localDemos());
        setError(
          "Backend offline. Only presentation records saved in this browser are shown. Start the backend and refresh.",
        );
      })
      .finally(() => setLoading(false));
  }, []);
  useEffect(refresh, [refresh]);
  return { items, error, loading, refresh };
}
function RecordList({ items }: { items: Incident[] }) {
  return (
    <div className="record-list">
      <div className="record-list-heading">
        <span>CALL / CLAIMED IDENTITY</span>
        <span>RISK</span>
        <span>STATUS</span>
        <span>WHEN</span>
      </div>
      {items.length ? (
        items.map((item) => (
          <Link
            className="record-row-item"
            to={`/incidents/${item.id}`}
            key={item.id}
          >
            <div className="record-identity">
              <span className={`record-icon ${item.risk.level.toLowerCase()}`}>
                <AudioLines size={19} />
              </span>
              <span>
                <strong>{item.identity}</strong>
                <small>
                  {item.id} ·{" "}
                  {item.mode === "DEMO_ANALYSIS" ? "DEMO" : "REAL ANALYSIS"}
                </small>
              </span>
            </div>
            <div className="record-risk">
              <strong>{item.risk.score}</strong>
              <Badge level={item.risk.level} />
            </div>
            <span className="record-status">{item.status}</span>
            <span className="record-time">
              {new Date(item.created).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })}
              <ArrowUpRight size={16} />
            </span>
          </Link>
        ))
      ) : (
        <div className="empty-state">
          <AudioLines size={35} />
          <h3>quiet is good.</h3>
          <p>No incidents yet. Run a demo or analyze a recording to start.</p>
          <Link to="/demo" className="button primary small">
            analyze a call <ArrowUpRight size={15} />
          </Link>
        </div>
      )}
    </div>
  );
}
export function Console() {
  const { items, error, loading, refresh } = useIncidents();
  const [health, setHealth] = useState<Health | null>(null);
  useEffect(() => {
    api<Health>("/health")
      .then(setHealth)
      .catch(() => {});
  }, []);
  const real = items.filter((i) => i.mode === "REAL_ANALYSIS");
  return (
    <AppShell>
      <div className="page-heading">
        <div>
          <span className="eyebrow">YOUR VOICE INTEGRITY WORKSPACE</span>
          <h1>
            a clearer picture<span className="accent">.</span>
          </h1>
          <p>Every assessment. Every signal. The next right step.</p>
        </div>
        <Link className="button primary" to="/demo">
          new analysis <ArrowUpRight size={18} />
        </Link>
      </div>
      {error && <ErrorNotice message={error} />}
      <div className="summary-grid">
        {[
          {
            label: "Calls analyzed",
            value: items.length,
            desc: `${real.length} real · ${items.length - real.length} presentation`,
            icon: AudioLines,
          },
          {
            label: "High / critical",
            value: items.filter((i) => i.risk.score >= 60).length,
            desc: "deserve a closer look",
            icon: Activity,
          },
          {
            label: "Verification required",
            value: items.filter((i) => i.status === "Verification required")
              .length,
            desc: "awaiting an independent check",
            icon: Phone,
          },
          {
            label: "Verification recorded",
            value: items.filter((i) => i.status === "Verification recorded")
              .length,
            desc: "manually logged by the operator",
            icon: Check,
          },
        ].map(({ label, value, desc, icon: Icon }) => (
          <div className="panel summary-card" key={label}>
            <div>
              <span>{label}</span>
              <Icon size={18} />
            </div>
            <strong>{value}</strong>
            <p>{desc}</p>
          </div>
        ))}
      </div>
      <div className="overview-grid">
        <section className="panel">
          <div className="panel-heading">
            <h2>recent assessment risk</h2>
            <span>CHRONOLOGICAL</span>
          </div>
          <RiskChart
            values={items
              .slice(0, 12)
              .reverse()
              .map((i) => i.risk.score)}
          />
          <p className="fineprint">
            Includes clearly labeled presentation records. Counts reflect saved
            assessments, not live phone traffic.
          </p>
        </section>
        <section className="panel engine-panel">
          <div className="panel-heading">
            <h2>engine room</h2>
            <Settings2 size={18} />
          </div>
          <div>
            <span>
              <i className="status-dot" /> Synthetic speech
            </span>
            <b>{health?.synthetic.state || "offline"}</b>
          </div>
          <p>
            {health?.synthetic.model || "Jabberjay"}{" "}
            <Source value="REAL_MODEL" />
          </p>
          <div>
            <span>Prosody features</span>
            <b>heuristic</b>
          </div>
          <div>
            <span>Context analysis</span>
            <b>English rules</b>
          </div>
          <div>
            <span>Speaker verification</span>
            <b>not configured</b>
          </div>
          <Link to="/architecture">
            see the full architecture <ArrowUpRight size={14} />
          </Link>
        </section>
      </div>
      <section className="panel records-panel">
        <div className="panel-heading">
          <h2>recent incidents</h2>
          <div>
            <button className="text-button" onClick={refresh}>
              {loading ? "loading…" : "refresh"}
            </button>
            <Link to="/incidents" className="text-button">
              view all <ArrowUpRight size={15} />
            </Link>
          </div>
        </div>
        <RecordList items={items.slice(0, 5)} />
      </section>
      <div className="console-banner">
        <div className="banner-icon">
          <GitBranch size={29} />
        </div>
        <div>
          <h3>the voice is only part of the story.</h3>
          <p>Use different verification thresholds for different stakes.</p>
        </div>
        <Link to="/settings" className="button secondary small">
          review policies <ArrowUpRight size={15} />
        </Link>
      </div>
    </AppShell>
  );
}

export function Incidents() {
  const { items, error, loading, refresh } = useIncidents();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const filtered = items.filter(
    (x) =>
      (filter === "all" || x.mode === filter) &&
      (x.identity + " " + x.id + " " + x.status)
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  return (
    <AppShell>
      <div className="page-heading">
        <div>
          <span className="eyebrow">THE RECORD, WITH CONTEXT</span>
          <h1>
            every call tells a story<span className="accent">.</span>
          </h1>
          <p>Review the evidence, record the response.</p>
        </div>
        <button className="button secondary small" onClick={refresh}>
          {loading ? "loading…" : "refresh records"}
        </button>
      </div>
      {error && <ErrorNotice message={error} />}
      <div className="list-toolbar">
        <label className="search-field">
          <Search size={17} />
          <input
            aria-label="Search incidents"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search identity, ID or status"
          />
        </label>
        <select
          aria-label="Filter incident source"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          <option value="all">All assessments</option>
          <option value="REAL_ANALYSIS">Real analysis</option>
          <option value="DEMO_ANALYSIS">Presentation demos</option>
        </select>
        <span>{filtered.length} records</span>
      </div>
      <section className="panel records-panel">
        <RecordList items={filtered} />
      </section>
      <p className="fineprint">
        Latest 200 backend records and up to 50 local presentation records. No
        raw recordings are retained.
      </p>
    </AppShell>
  );
}

export function IncidentDetail() {
  const { id } = useParams();
  const [item, setItem] = useState<Incident | null>(null);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    setItem(null);
    setError("");
    if (id?.startsWith("LOCAL-")) {
      const local = localDemos().find((x) => x.id === id);
      if (local) setItem(local);
      else setError("This local demo record was not found in this browser.");
    } else
      api<Incident>(`/incidents/${id}`)
        .then(setItem)
        .catch((e) => setError(e.message));
  }, [id]);
  async function action(value: string) {
    if (!item) return;
    setBusy(true);
    setError("");
    try {
      if (item.id.startsWith("LOCAL-")) {
        const updated = {
          ...item,
          status:
            value === "Verification completed"
              ? "Verification recorded"
              : value,
          history: [
            ...item.history,
            { at: new Date().toISOString(), action: value, note },
          ],
        };
        saveLocalDemo(updated);
        setItem(updated);
      } else
        setItem(
          await api<Incident>(`/incidents/${item.id}`, {
            method: "PATCH",
            body: JSON.stringify({ action: value, note }),
          }),
        );
      setMessage(
        "Action recorded. No callback, MFA message or supervisor notification was sent.",
      );
      setNote("");
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Could not save action. Please retry.",
      );
    } finally {
      setBusy(false);
    }
  }
  function exportReport() {
    if (!item) return;
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(item, null, 2)], { type: "application/json" }),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = `${item.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
  return (
    <AppShell>
      <Link className="text-button back-link" to="/incidents">
        <ArrowLeft size={16} /> all incidents
      </Link>
      {error && <ErrorNotice message={error} />}{" "}
      {!item ? (
        <div className="empty-state">
          <FileAudio size={32} />
          <h2>{error ? "record unavailable." : "opening the evidence…"}</h2>
          <Link to="/demo">Start a new analysis</Link>
        </div>
      ) : (
        <>
          <div className="page-heading">
            <div>
              <span className="eyebrow">{item.id} / INCIDENT DETAIL</span>
              <h1>{item.identity}</h1>
              <p>
                <Clock size={14} /> {new Date(item.created).toLocaleString()} ·{" "}
                {item.status}
              </p>
            </div>
            <button className="button secondary small" onClick={exportReport}>
              <Download size={16} /> export evidence
            </button>
          </div>
          <div className="incident-source">
            <Source value={item.mode} />
            <span>
              {item.mode === "DEMO_ANALYSIS"
                ? "Presentation fixture. Acoustic and identity scores are simulated."
                : "Acoustic model inference. Transcript, if present, was supplied by the user."}
            </span>
          </div>
          <div className="detail-grid">
            <div>
              <section className="panel">
                <div className="panel-heading">
                  <h2>the call, at a glance.</h2>
                  <span>{item.duration}s</span>
                </div>
                <Waveform peaks={item.waveform} />
                {item.audio && (
                  <>
                    <audio controls src={item.audio} />
                    <p className="fineprint">
                      Computer-generated scenario narration; not validation
                      audio.
                    </p>
                  </>
                )}
                <RiskChart
                  values={item.timeline}
                  threshold={item.policy.threshold}
                />
                <p className="fineprint">
                  {item.mode === "DEMO_ANALYSIS"
                    ? "Scripted progression for presentation."
                    : "Acoustic score by window, with clip-level context. No transcript time alignment."}
                </p>
              </section>
              <section className="panel">
                <div className="panel-heading">
                  <h2>words worth a second thought.</h2>
                  <Source value={item.transcript_source} />
                </div>
                <Transcript text={item.transcript} signals={item.signals} />
                <div className="signal-explanations">
                  {item.signals.map((s) => (
                    <div key={s.type}>
                      <span className="signal-dot" />
                      <div>
                        <strong>{s.type.replaceAll("_", " ")}</strong>
                        <p>{s.explanation}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
              <section className="panel">
                <div className="panel-heading">
                  <h2>action history</h2>
                  <span>{item.history.length} ENTRIES</span>
                </div>
                {item.history.length ? (
                  item.history.map((entry, i) => (
                    <div className="history-item" key={i}>
                      <span className="history-dot" />
                      <div>
                        <strong>{entry.action}</strong>
                        <p>{entry.note || "No note added."}</p>
                        <small>{new Date(entry.at).toLocaleString()}</small>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="muted">
                    No verification actions have been recorded yet.
                  </p>
                )}
              </section>
            </div>
            <aside>
              <section
                className={`panel risk-panel ${item.risk.level.toLowerCase()}`}
              >
                <div className="panel-heading">
                  <span>OVERALL RISK</span>
                  <Badge level={item.risk.level} />
                </div>
                <div className="risk-number">
                  {item.risk.score}
                  <span>/100</span>
                </div>
                <p>{item.risk.coverage}% weighted signal coverage</p>
                {!!item.risk.missing.length && (
                  <small>Unavailable: {item.risk.missing.join(", ")}</small>
                )}
                <Metrics metrics={item.metrics} />
              </section>
              <section className="panel action-panel">
                <div className="panel-heading">
                  <h2>verify before you act.</h2>
                  <Phone size={19} />
                </div>
                <p>{item.policy.recommendation}</p>
                <small>{item.policy.reason}</small>
                <label>
                  Operator note
                  <textarea
                    value={note}
                    maxLength={500}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="Record the independent check you requested or completed."
                    rows={3}
                  />
                </label>
                {[
                  "Callback requested",
                  "MFA requested",
                  "Escalated to supervisor",
                  "Verification completed",
                ].map((a) => (
                  <button
                    key={a}
                    disabled={busy}
                    className="button secondary"
                    onClick={() => action(a)}
                  >
                    {a}
                    <ArrowUpRight size={15} />
                  </button>
                ))}
                <p className="fineprint">
                  These buttons record operator actions only. Completing
                  verification is a manual attestation, not an automated
                  identity check.
                </p>
                {message && (
                  <div className="notice" role="status">
                    {message}
                  </div>
                )}
              </section>
            </aside>
          </div>
        </>
      )}
    </AppShell>
  );
}

export function Settings() {
  const [value, setValue] = useState({
    normal: 75,
    payment: 45,
    privileged: 40,
  });
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    api<typeof value>("/settings")
      .then(setValue)
      .catch(() =>
        setError(
          "Backend unavailable. Displaying prototype defaults; changes cannot be saved until the server is online.",
        ),
      );
  }, []);
  async function save() {
    setBusy(true);
    setMessage("");
    setError("");
    try {
      setValue(
        await api<typeof value>("/settings", {
          method: "PUT",
          body: JSON.stringify(value),
        }),
      );
      setMessage(
        "Policies saved. New analyses use these thresholds; historical decisions are preserved.",
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save policies.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <AppShell>
      <div className="page-heading">
        <div>
          <span className="eyebrow">YOUR POLICY, IN CONTEXT</span>
          <h1>
            set the moment to verify<span className="accent">.</span>
          </h1>
          <p>Lower thresholds ask for verification earlier.</p>
        </div>
      </div>
      {error && <ErrorNotice message={error} />}
      <div className="settings-grid">
        <section className="panel">
          <h2>verification thresholds</h2>
          <p>
            These prototype defaults need calibration to your workflow and
            tolerance for false alarms.
          </p>
          {Object.entries({
            normal: "Everyday conversation",
            payment: "High-value payment",
            privileged: "Privileged access",
          }).map(([k, label]) => (
            <label className="threshold-setting" key={k}>
              <div>
                <span>{label}</span>
                <b>
                  {value[k as keyof typeof value]}
                  <small>/100</small>
                </b>
              </div>
              <input
                type="range"
                min="1"
                max="100"
                value={value[k as keyof typeof value]}
                onChange={(e) =>
                  setValue({ ...value, [k]: Number(e.target.value) })
                }
              />
              <small>
                Recommend independent verification at or above this score.
              </small>
            </label>
          ))}
          <div className="notice">
            Credential requests, anti-verification language and high-value
            amounts trigger a verification recommendation independently of the
            weighted score.
          </div>
          <button onClick={save} disabled={busy} className="button primary">
            {busy ? "saving…" : "save policies"}
            <Check size={16} />
          </button>
          {message && (
            <p className="success-text" role="status">
              {message}
            </p>
          )}
        </section>
        <aside>
          <section className="panel">
            <h2>risk fusion defaults</h2>
            <div className="weight-list">
              {[
                ["Synthetic speech", "40%"],
                ["Speaker mismatch", "25%"],
                ["Prosody heuristic", "15%"],
                ["Context rules", "20%"],
              ].map(([k, v]) => (
                <div key={k}>
                  <span>{k}</span>
                  <strong>{v}</strong>
                </div>
              ))}
            </div>
            <p className="fineprint">
              Missing signals are excluded and remaining weights renormalized.
              Coverage is always displayed. Real analysis has no speaker score.
            </p>
          </section>
          <section className="panel">
            <h2>privacy by default</h2>
            <p>
              Raw audio is processed temporarily. Incident scores and operator
              notes are stored in local SQLite. Transcript retention is opt-in
              per upload.
            </p>
            <p className="fineprint">
              Local prototype, without authentication. Do not expose it to a
              public network or use it as the sole control for real
              transactions.
            </p>
          </section>
        </aside>
      </div>
    </AppShell>
  );
}

export function VoiceProfiles() {
  return (
    <AppShell>
      <div className="page-heading">
        <div>
          <span className="eyebrow">SPEAKER CONSISTENCY</span>
          <h1>
            no trusted voice yet<span className="accent">.</span>
          </h1>
          <p>An honest place for what comes next.</p>
        </div>
        <Source value="PLANNED" />
      </div>
      <section className="panel profile-placeholder">
        <div className="profile-orbit">
          <Users size={44} />
        </div>
        <h2>familiar is a starting point.</h2>
        <p>
          Voice enrollment and speaker embeddings are not implemented in this
          build. Uploaded calls show this signal as unavailable, never as a
          simulated match.
        </p>
        <div className="profile-roadmap">
          <span>consented reference</span>
          <ArrowUpRight size={16} />
          <span>speaker embedding</span>
          <ArrowUpRight size={16} />
          <span>cosine similarity</span>
        </div>
        <p className="fineprint">
          A future ECAPA-TDNN integration can compare speaker characteristics.
          Similarity does not prove liveness: replay and cloning remain
          possible. A fresh challenge and independent channel still matter.
        </p>
        <Link to="/demo" className="button primary">
          analyze available signals <ArrowUpRight size={17} />
        </Link>
      </section>
    </AppShell>
  );
}

export function Architecture() {
  return (
    <AppShell>
      <div className="page-heading">
        <div>
          <span className="eyebrow">UNDER THE HOOD</span>
          <h1>
            no mystery in the middle<span className="accent">.</span>
          </h1>
          <p>One voice, independent evidence, a considered next step.</p>
        </div>
        <Source value="PROTOTYPE" />
      </div>
      <section className="architecture-board dot-grid">
        <div className="architecture-board-title">
          <AudioLines size={25} />
          <span>THE VOXSUS PIPELINE</span>
          <small>detect → assess → verify → prevent</small>
        </div>
        <ArchitectureGraphic />
        <div className="architecture-sources">
          <span>
            <i className="status-dot" /> real acoustic inference
          </span>
          <span>
            <i className="status-dot amber" /> heuristic / rule signals
          </span>
          <span>
            <i className="status-dot gray" /> speaker & STT planned
          </span>
        </div>
      </section>
      <div className="architecture-explain">
        <section className="panel">
          <span className="eyebrow">INPUT → PROCESS → OUTPUT</span>
          <h2>every block has a reason.</h2>
          {[
            {
              title: "01 / audio preprocessing",
              text: "WAV or FLAC → validate size, duration and decoded data → downmix and resample to mono 16 kHz. Process independent 5-second windows.",
            },
            {
              title: "02 / synthetic detector",
              text: "Audio samples → pretrained HuBERT through Jabberjay → synthetic model score. One active detector; the adapter supports adding measured detectors later.",
            },
            {
              title: "03 / prosody & context",
              text: "Audio → energy and silence measurements → heuristic. Optional user transcript → English lexical rules → threats and phrase spans. These do not decide whether the audio is synthetic.",
            },
            {
              title: "04 / risk fusion",
              text: "Available scores → configurable-in-code weights, normalized for missing signals → 0–100 risk index, level and coverage. This is not a calibrated probability of fraud.",
            },
            {
              title: "05 / policy & prevention",
              text: "Risk + sensitive request + workflow threshold → verification recommendation. SQLite records the evidence and operator actions. External callback, MFA and transaction controls are not connected.",
            },
          ].map((x) => (
            <article key={x.title}>
              <h3>{x.title}</h3>
              <p>{x.text}</p>
            </article>
          ))}
        </section>
        <aside>
          <section className="panel">
            <h2>our contribution</h2>
            <p>
              The original Voxsus experience, audio-window workflow, evidence
              provenance, risk fusion, contextual policy and incident response.
            </p>
            <p>
              Jabberjay provides the reusable detection interface. We did not
              train its underlying foundation models.
            </p>
            <a
              href="https://github.com/MattyB95/Jabberjay"
              target="_blank"
              rel="noreferrer"
              className="text-button"
            >
              Jabberjay · MIT <ArrowUpRight size={15} />
            </a>
          </section>
          <section className="panel">
            <h2>honest boundaries</h2>
            <ul className="boundary-list">
              <li>
                Unseen synthesis, noise and compression can fool detectors.
              </li>
              <li>No claim of production accuracy or guaranteed identity.</li>
              <li>Presentation scores are deterministic simulation.</li>
              <li>
                Speaker verification and speech-to-text are not implemented.
              </li>
              <li>
                Indian-language context support needs models and evaluation.
              </li>
              <li>No telecom, bank or collaboration-platform integration.</li>
            </ul>
          </section>
          <section className="panel">
            <h2>hear less. keep less.</h2>
            <p>
              No raw audio is permanently retained. Transcripts are opt-in.
              Scores and action history live in local SQLite. Edge inference and
              institutional access controls are future deployment work.
            </p>
          </section>
        </aside>
      </div>
    </AppShell>
  );
}
