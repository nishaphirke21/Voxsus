import { useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  ArrowUpRight,
  AudioLines,
  Check,
  ChevronDown,
  Phone,
  Play,
  ScanLine,
  Sparkles,
  Volume2,
  FileAudio,
  Building2,
  Landmark,
  Headphones,
  Radio,
  Plus,
} from "lucide-react";
import {
  Header,
  Footer,
  Voiceprint,
  Badge,
  Reveal,
  ArchitectureGraphic,
  Waveform,
} from "./components";

const steps = [
  {
    title: "detect.",
    body: "Listen for the acoustic patterns of synthetic speech.",
    detail:
      "One real HuBERT detector, through Jabberjay. Model scores are evidence, never a guarantee of identity.",
    icon: ScanLine,
  },
  {
    title: "assess.",
    body: "Bring the voice and the request into the same picture.",
    detail:
      "Combine available acoustic, prosody and contextual signals. Missing evidence stays visible.",
    icon: AudioLines,
  },
  {
    title: "verify.",
    body: "Make the next step a thoughtful one.",
    detail:
      "Choose registered callback, MFA or a supervisor when the action deserves stronger verification.",
    icon: Phone,
  },
  {
    title: "prevent.",
    body: "Put a pause between pressure and a costly decision.",
    detail:
      "Voxsus recommends a pause and records the response. It does not connect to or block real banking systems.",
    icon: Check,
  },
];
export default function Home() {
  const [step, setStep] = useState(0);
  const [voice, setVoice] = useState(false);
  const [workflow, setWorkflow] = useState("payment");
  return (
    <>
      <Header />
      <main id="main-content">
        <section className="hero dot-grid">
          <div className="hero-topline">
            <span className="eyebrow">
              <i className="status-dot" /> VOICE INTEGRITY, REIMAGINED
            </span>
            <span className="edition">an SIH prototype / 01</span>
          </div>
          <div className="hero-copy">
            <div className="eyebrow hero-label">
              A LITTLE MORE SIGNAL. A LOT LESS DOUBT.
            </div>
            <h1>
              sounds familiar.
              <br />
              <span>is it really?</span>
              <svg
                className="underline"
                viewBox="0 0 430 25"
                aria-hidden="true"
              >
                <path d="M5 15Q185-4 420 9M50 23Q270 6 391 19" />
              </svg>
            </h1>
            <p>
              A voice can be cloned. Your trust shouldn’t be.
              <br />
              Meet the voice integrity layer that helps you
              <br className="desktop-break" /> verify before you act.
            </p>
            <div className="hero-actions">
              <Link to="/demo" className="button primary" data-cursor="try">
                <AudioLines size={19} /> try a voice <ArrowUpRight size={18} />
              </Link>
              <a href="#how" className="text-button">
                see how it works <ArrowRight size={17} />
              </a>
            </div>
            <div className="hero-caption">
              <span className="tiny-wave">ıılıı</span> listen deeper. decide
              better.
            </div>
          </div>
          <div className="floating-note note-one">
            <span className="note-tag">
              <Phone size={12} /> INCOMING CALL
            </span>
            <div className="caller-avatar">AK</div>
            <strong>“it’s me, the CFO.”</strong>
            <small>familiar doesn’t mean verified.</small>
            <span className="note-corner">?</span>
          </div>
          <div className="floating-note note-two">
            <span className="note-tag">
              <ScanLine size={13} /> ANOTHER LAYER OF LISTENING
            </span>
            <div className="mini-wave">
              <Waveform />
            </div>
            <Badge level="CAUTION">verify before you act</Badge>
          </div>
          <div className="hand-note note-left">
            a voice is a signal,
            <br />
            not a signature.
            <svg viewBox="0 0 100 70" aria-hidden="true">
              <path d="M5 5Q15 65 90 40m-12-9 14 9-12 10" />
            </svg>
          </div>
          <div className="spark spark-one" aria-hidden="true">
            ✳
          </div>
          <div className="spark spark-two" aria-hidden="true">
            +
          </div>
          <button
            className={`voice-stage ${voice ? "suspicious" : ""}`}
            data-cursor="listen"
            onClick={() => setVoice(!voice)}
            aria-label="Switch illustrative voice risk"
          >
            <div className="voice-stage-top">
              <span>
                <i className="status-dot" />{" "}
                {voice ? "READING THE REQUEST" : "LISTENING BEYOND THE VOICE"}
              </span>
              <span>ILLUSTRATIVE SIGNAL</span>
            </div>
            <Voiceprint />
            <div className="voice-stage-bottom">
              <span>
                <Volume2 size={16} />{" "}
                {voice
                  ? "“transfer it. don’t call me back.”"
                  : "there’s more to a voice than what you hear."}
              </span>
              <span className="stage-action">
                tap to listen deeper <ArrowUpRight size={15} />
              </span>
            </div>
          </button>
          <a className="scroll-cue" href="#try">
            a familiar voice. a new perspective. <ChevronDown size={14} />
          </a>
        </section>
        <div className="audience-strip">
          <span>BUILT FOR CALLS THAT MATTER</span>
          <div>
            <Landmark size={18} /> financial institutions
          </div>
          <div>
            <Building2 size={18} /> enterprises
          </div>
          <div>
            <Headphones size={18} /> contact centers
          </div>
          <div>
            <Radio size={18} /> public services
          </div>
        </div>
        <section id="try" className="section demo-preview">
          <Reveal className="section-heading">
            <span className="eyebrow">01 / HEAR THE DIFFERENCE</span>
            <h2>
              same voice.
              <br />
              <span className="muted-heading">different intentions.</span>
            </h2>
            <p>
              Take two calls. Watch the risk change.
              <br />
              See why what’s being asked matters, too.
            </p>
          </Reveal>
          <Reveal className="scenario-cards">
            <Link
              to="/demo?scenario=genuine"
              className="scenario-card green"
              data-cursor="listen"
            >
              <div className="scenario-meta">
                <span>SCENARIO A</span>
                <Badge level="LOW" />
              </div>
              <div className="scenario-icon">
                <Phone size={26} />
                <span className="small-tick">
                  <Check size={12} />
                </span>
              </div>
              <h3>just the usual.</h3>
              <p>
                “Could you send me today’s
                <br />
                sales report?”
              </p>
              <div className="scenario-card-bottom">
                <span>the genuine executive scenario</span>
                <span className="round-play">
                  <Play size={16} fill="currentColor" />
                </span>
              </div>
            </Link>
            <Link
              to="/demo?scenario=cloned"
              className="scenario-card coral"
              data-cursor="inspect"
            >
              <div className="scenario-meta">
                <span>SCENARIO B</span>
                <Badge level="CRITICAL" />
              </div>
              <div className="scenario-icon">
                <AudioLines size={29} />
                <span className="small-question">?</span>
              </div>
              <h3>something’s off.</h3>
              <p>
                “Transfer ₹25 lakh now.
                <br />
                Don’t call me back.”
              </p>
              <div className="scenario-card-bottom">
                <span>the cloned CFO scenario</span>
                <span className="round-play">
                  <Play size={16} fill="currentColor" />
                </span>
              </div>
            </Link>
            <p className="fineprint">
              Presentation scenarios use simulated scores. Upload a recording
              for real acoustic analysis.
            </p>
          </Reveal>
        </section>
        <section className="problem-section section">
          <Reveal>
            <span className="eyebrow">
              THE VOICE IS FAMILIAR. THE RULES HAVE CHANGED.
            </span>
            <h2>
              “I know that voice”
              <br />
              used to be enough<span className="accent">.</span>
            </h2>
            <p>
              A familiar voice and an urgent request can turn trust into a
              vulnerability.
              <br />
              Voxsus adds a moment of clarity before a sensitive decision.
            </p>
            <div className="attack-path">
              <span>public audio</span>
              <ArrowRight />
              <span>cloned voice</span>
              <ArrowRight />
              <span>urgent request</span>
              <ArrowRight />
              <span className="path-stop">pause. verify.</span>
            </div>
          </Reveal>
        </section>
        <section className="section how-section" id="how">
          <Reveal className="section-heading">
            <span className="eyebrow">02 / A SECOND PAIR OF EARS</span>
            <h2>
              listen. understand.
              <br />
              <span className="muted-heading">then decide.</span>
            </h2>
            <p>
              More than a fake-or-real label.
              <br />A clear path from evidence to action.
            </p>
          </Reveal>
          <Reveal className="steps-panel">
            <div
              className="steps-tabs"
              role="tablist"
              aria-label="How Voxsus works"
            >
              {steps.map((s, i) => (
                <button
                  key={s.title}
                  role="tab"
                  id={`step-${i}`}
                  aria-selected={step === i}
                  aria-controls="step-panel"
                  onClick={() => setStep(i)}
                >
                  <span>0{i + 1}</span>
                  {s.title}
                </button>
              ))}
            </div>
            <div
              role="tabpanel"
              id="step-panel"
              aria-labelledby={`step-${step}`}
              className="step-content"
              key={step}
            >
              {(() => {
                const Icon = steps[step].icon;
                return (
                  <div className="step-illustration">
                    <div className="orbit orbit-one" />
                    <div className="orbit orbit-two" />
                    <span>
                      <Icon size={40} />
                    </span>
                    <div className="step-chip">
                      <i className="status-dot" />{" "}
                      {steps[step].title.replace(".", "")} in context
                    </div>
                  </div>
                );
              })()}
              <h3>{steps[step].body}</h3>
              <p>{steps[step].detail}</p>
            </div>
          </Reveal>
        </section>
        <section className="layers-section section">
          <Reveal>
            <div className="center-heading">
              <span className="eyebrow">
                03 / EVIDENCE, FROM MORE THAN ONE ANGLE
              </span>
              <h2>one voice. multiple signals.</h2>
              <p>Every signal has a source. Every score has its limits.</p>
            </div>
            <div className="layers-grid">
              {[
                {
                  n: "01",
                  title: "synthetic speech",
                  body: "A pretrained HuBERT model looks for acoustic patterns associated with generated speech.",
                  tag: "REAL MODEL",
                  icon: AudioLines,
                },
                {
                  n: "02",
                  title: "speaker consistency",
                  body: "A future trusted voice profile adds identity comparison. Similarity alone will not prove liveness.",
                  tag: "PLANNED",
                  icon: ScanLine,
                },
                {
                  n: "03",
                  title: "prosody & rhythm",
                  body: "Energy variation and pauses add interpretable context. A heuristic, never definitive proof.",
                  tag: "HEURISTIC",
                  icon: ActivityIcon,
                },
                {
                  n: "04",
                  title: "the actual request",
                  body: "English rules identify money, secrets, urgency and attempts to discourage verification.",
                  tag: "RULE BASED",
                  icon: FileAudio,
                },
              ].map(({ n, title, body, tag, icon: Icon }) => (
                <article className="layer" key={n}>
                  <div>
                    <span>{n}</span>
                    <Icon size={22} />
                  </div>
                  <h3>{title}</h3>
                  <p>{body}</p>
                  <span className="source">{tag}</span>
                </article>
              ))}
            </div>
          </Reveal>
        </section>
        <section className="section policy-section">
          <Reveal className="policy-visual">
            <div className="paper-label">POLICY EXPLORER</div>
            <div className="policy-score">
              <span>same risk score</span>
              <strong>
                52<span>/100</span>
              </strong>
            </div>
            <div className="segmented">
              <button
                className={workflow === "normal" ? "selected" : ""}
                onClick={() => setWorkflow("normal")}
              >
                everyday call
              </button>
              <button
                className={workflow === "payment" ? "selected" : ""}
                onClick={() => setWorkflow("payment")}
              >
                payment approval
              </button>
            </div>
            <div className="policy-track">
              <span />
              <i style={{ left: workflow === "payment" ? "45%" : "75%" }} />
              <b style={{ left: "52%" }} />
            </div>
            <div className="policy-legend">
              <span>0</span>
              <span>verify at {workflow === "payment" ? 45 : 75}</span>
              <span>100</span>
            </div>
            <div
              className={`policy-verdict ${workflow === "payment" ? "alert" : ""}`}
            >
              <span>
                {workflow === "payment" ? (
                  <Phone size={18} />
                ) : (
                  <Check size={18} />
                )}
              </span>
              <div>
                <strong>
                  {workflow === "payment"
                    ? "pause. verify independently."
                    : "below the alert threshold."}
                </strong>
                <small>
                  {workflow === "payment"
                    ? "A sensitive action deserves a stronger check."
                    : "Normal verification procedures still apply."}
                </small>
              </div>
            </div>
            <small className="fineprint">
              Illustrative policy example · prototype thresholds
            </small>
          </Reveal>
          <Reveal className="section-heading">
            <span className="eyebrow">04 / TRUST IS CONTEXTUAL</span>
            <h2>
              what’s at stake
              <br />
              changes everything.
            </h2>
            <p>
              A sales report and a ₹25 lakh transfer shouldn’t get the same
              decision. Your policy sets when stronger verification is needed.
            </p>
            <Link className="text-button" to="/settings">
              explore your thresholds <ArrowRight size={17} />
            </Link>
          </Reveal>
        </section>
        <section id="privacy" className="privacy-section section">
          <Reveal className="privacy-art">
            <div className="privacy-circle">
              <AudioLines size={56} />
              <div className="privacy-check">
                <Check size={28} />
              </div>
            </div>
            <span className="hand-note">
              keep the insight.
              <br />
              let the audio go.
            </span>
          </Reveal>
          <Reveal>
            <span className="eyebrow">05 / LESS TO KEEP. MORE TO TRUST.</span>
            <h2>
              hear less.
              <br />
              know enough.
            </h2>
            <p>
              Your recording is processed temporarily. Raw audio is not kept.
              Keep an optional transcript only when you choose to.
            </p>
            <div className="privacy-points">
              <span>
                <Check size={16} /> local acoustic inference
              </span>
              <span>
                <Check size={16} /> no permanent audio storage
              </span>
              <span>
                <Check size={16} /> visible evidence sources
              </span>
            </div>
            <Link to="/architecture" className="text-button">
              the privacy approach <ArrowRight size={16} />
            </Link>
          </Reveal>
        </section>
        <section className="section architecture-section">
          <Reveal>
            <div className="center-heading">
              <span className="eyebrow">06 / OPEN UP THE BLACK BOX</span>
              <h2>built to be understood.</h2>
              <p>
                Original risk orchestration. Open-source detection.
                <br />A transparent path to a better decision.
              </p>
            </div>
            <ArchitectureGraphic />
            <div className="center">
              <Link to="/architecture" className="button secondary">
                explore the architecture <ArrowUpRight size={17} />
              </Link>
            </div>
          </Reveal>
        </section>
        <section className="section faq-section">
          <h2>a few good questions.</h2>
          <div>
            {[
              {
                q: "Can Voxsus prove who is calling?",
                a: "No. A synthetic speech score is one piece of evidence. Independent verification is still necessary for sensitive requests. Speaker verification is planned, and even a speaker match would not rule out a replay.",
              },
              {
                q: "What is real in this prototype?",
                a: "Audio upload runs Jabberjay with a HuBERT detector, lightweight prosody features, English transcript rules, backend risk fusion and configurable policies. The two presentation scenarios are explicitly simulated.",
              },
              {
                q: "Does it listen to my phone calls?",
                a: "No. This local prototype analyzes recordings you upload. It processes five-second windows sequentially. Telecom integrations and true live call interception are future work.",
              },
              {
                q: "Which languages can I use?",
                a: "The context rules currently support English. Acoustic inference runs on audio, but performance across Indian languages and accents has not been validated. Multilingual transcription and evaluation are planned.",
              },
            ].map((x) => (
              <details key={x.q}>
                <summary>
                  {x.q}
                  <Plus size={18} />
                </summary>
                <p>{x.a}</p>
              </details>
            ))}
          </div>
        </section>
        <section className="final-cta dot-grid">
          <span className="eyebrow">
            A SECOND THOUGHT CAN CHANGE EVERYTHING.
          </span>
          <h2>
            before “of course”,
            <br />a little <span>voxsus.</span>
          </h2>
          <Link to="/demo" className="button primary" data-cursor="try">
            let’s listen deeper <ArrowUpRight size={19} />
          </Link>
          <span className="cta-spark" aria-hidden="true">
            <Sparkles size={50} />
          </span>
        </section>
      </main>
      <Footer />
    </>
  );
}
function ActivityIcon({ size }: { size?: number }) {
  return <AudioLines size={size} />;
}
