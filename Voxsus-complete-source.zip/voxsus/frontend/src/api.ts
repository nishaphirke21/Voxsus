import type { Incident } from "./types";
export async function api<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`/api${path}`, {
    ...options,
    headers: {
      ...(options?.body instanceof FormData
        ? {}
        : { "Content-Type": "application/json" }),
      ...options?.headers,
    },
  });
  if (!response.ok) {
    const data = await response
      .json()
      .catch(() => ({ detail: "Service unavailable." }));
    throw new Error(
      typeof data.detail === "string"
        ? data.detail
        : "Please check your input and try again.",
    );
  }
  return response.json();
}
export function localDemos(): Incident[] {
  try {
    return JSON.parse(localStorage.getItem("voxsus-demo-incidents") || "[]");
  } catch {
    return [];
  }
}
export function saveLocalDemo(item: Incident) {
  localStorage.setItem(
    "voxsus-demo-incidents",
    JSON.stringify(
      [item, ...localDemos().filter((x) => x.id !== item.id)].slice(0, 50),
    ),
  );
}
export async function allIncidents(): Promise<Incident[]> {
  const real = await api<Incident[]>("/incidents");
  return [...real, ...localDemos()].sort((a, b) =>
    b.created.localeCompare(a.created),
  );
}
