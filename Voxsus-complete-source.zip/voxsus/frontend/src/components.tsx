import { useEffect, useRef, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import {
  ArrowUpRight,
  AudioLines,
  Menu,
  X,
  ArrowRight,
  Activity,
  ScanLine,
  PhoneCall,
  Check,
  GitBranch,
  LayoutDashboard,
  SlidersHorizontal,
  List,
  Users,
  AlertCircle,
} from "lucide-react";
import type { Incident, Metric } from "./types";

export function Brand() {
  return (
    <Link to="/" className="brand" aria-label="Voxsus home">
      <svg viewBox="0 0 40 40" aria-hidden="true">
        <path d="M6 12v9m7-14v21m7-10v16m7-27v21m7-16v9" />
      </svg>
      <span>
        voxsus<span className="brand-period">.</span>
      </span>
    </Link>
  );
}
export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="site-header">
      <Brand />
      <nav
        className={open ? "site-nav is-open" : "site-nav"}
        aria-label="Main navigation"
      >
        <a href="/#how" onClick={() => setOpen(false)}>
          how it works
        </a>
        <NavLink to="/demo" onClick={() => setOpen(false)}>
          live demo
        </NavLink>
        <a href="/#privacy" onClick={() => setOpen(false)}>
          privacy
        </a>
        <NavLink to="/architecture" onClick={() => setOpen(false)}>
          architecture
        </NavLink>
      </nav>
      <Link className="button small dark header-cta" to="/console">
        open console <ArrowUpRight size={15} />
      </Link>
      <button
        className="icon-button menu"
        aria-label={open ? "Close menu" : "Open menu"}
        aria-expanded={open}
        onClick={() => setOpen(!open)}
      >
        {open ? <X /> : <Menu />}
      </button>
    </header>
  );
}
export function Footer() {
  return (
    <footer>
      <Brand />
      <p>listen deeper. act with confidence.</p>
      <div>
        <Link to="/architecture">
          under the hood <ArrowUpRight size={14} />
        </Link>
        <span>SIH 26104 · prototype</span>
      </div>
    </footer>
  );
}
export function Arrow({ size = 18 }: { size?: number }) {
  return <ArrowUpRight size={size} />;
}
export function Badge({
  level = "LOW",
  children,
}: {
  level?: string;
  children?: React.ReactNode;
}) {
  return (
    <span className={`badge ${level.toLowerCase()}`}>
      <i />
      {children || level}
    </span>
  );
}
export function Source({ value }: { value: string }) {
  return (
    <span className={`source ${value.toLowerCase()}`}>
      {value.replaceAll("_", " ")}
    </span>
  );
}
export function Waveform({
  active = false,
  peaks,
  progress = 0,
}: {
  active?: boolean;
  peaks?: number[];
  progress?: number;
}) {
  const bars =
    peaks ||
    Array.from(
      { length: 72 },
      (_, i) => 0.1 + Math.abs(Math.sin(i * 0.64) * Math.cos(i * 0.21)) * 0.85,
    );
  return (
    <div
      className={`waveform ${active ? "playing" : ""}`}
      role="img"
      aria-label={
        peaks ? "Audio energy waveform" : "Illustrative voice waveform"
      }
    >
      {bars.map((v, i) => (
        <span
          key={i}
          className={i / bars.length < progress ? "passed" : ""}
          style={{
            height: `${Math.max(5, v * 100)}%`,
            animationDelay: `${-i * 0.09}s`,
          }}
        />
      ))}
    </div>
  );
}
export function Voiceprint() {
  return (
    <svg
      className="voiceprint"
      viewBox="0 0 720 240"
      role="img"
      aria-label="Original layered voiceprint illustration"
    >
      <defs>
        <linearGradient id="voice-gradient">
          <stop stopColor="#a8b7ff" />
          <stop offset=".48" stopColor="#3158ee" />
          <stop offset="1" stopColor="#a8b7ff" />
        </linearGradient>
      </defs>
      {Array.from({ length: 22 }, (_, j) => {
        const points = Array.from({ length: 121 }, (_, i) => {
          const x = i * 6;
          const envelope = Math.exp(-(((x - 360) / 175) ** 2));
          const y =
            120 + Math.sin(x * 0.037 + j * 0.1) * envelope * (35 + j * 3.2);
          return `${i ? "L" : "M"}${x.toFixed(1)},${y.toFixed(1)}`;
        }).join(" ");
        return (
          <path
            key={j}
            d={points}
            fill="none"
            stroke="url(#voice-gradient)"
            strokeWidth="1.25"
            opacity={0.35 + j * 0.026}
          />
        );
      })}
    </svg>
  );
}
export function RiskChart({
  values,
  threshold = 45,
}: {
  values: number[];
  threshold?: number;
}) {
  const data = values.length ? values : [0];
  const points = data
    .map(
      (v, i) => `${24 + i * (552 / Math.max(data.length - 1, 1))},${132 - v}`,
    )
    .join(" ");
  return (
    <div className="risk-chart">
      <svg
        viewBox="0 0 600 164"
        role="img"
        aria-label={`Risk progression: ${data.join(", ")}. Alert threshold ${threshold}.`}
      >
        <defs>
          <linearGradient id="chart-fill" x1="0" y1="0" x2="0" y2="1">
            <stop stopColor="currentColor" stopOpacity=".15" />
            <stop offset="1" stopColor="currentColor" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[30, 60, 90].map((v) => (
          <line
            key={v}
            x1="24"
            x2="578"
            y1={132 - v}
            y2={132 - v}
            stroke="#e8eaf0"
          />
        ))}
        <line
          x1="24"
          x2="578"
          y1={132 - threshold}
          y2={132 - threshold}
          stroke="#a1a6b4"
          strokeDasharray="4 5"
        />
        <text x="25" y={125 - threshold} fill="#747b8e" fontSize="9">
          verification threshold · {threshold}
        </text>
        <polygon
          points={`24,132 ${points} ${24 + (data.length - 1) * (552 / Math.max(data.length - 1, 1))},132`}
          fill="url(#chart-fill)"
        />
        <polyline
          points={points}
          stroke="currentColor"
          strokeWidth="3"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {data.map((v, i) => (
          <circle
            key={i}
            cx={24 + i * (552 / Math.max(data.length - 1, 1))}
            cy={132 - v}
            r="4"
            fill="currentColor"
            stroke="white"
            strokeWidth="2"
          />
        ))}
        <text x="24" y="157" fontSize="10" fill="#747b8e">
          start of assessment
        </text>
        <text x="578" y="157" textAnchor="end" fontSize="10" fill="#747b8e">
          latest
        </text>
      </svg>
    </div>
  );
}
const labels: Record<string, string> = {
  synthetic: "Synthetic voice",
  speaker: "Speaker mismatch",
  prosody: "Prosody anomaly",
  context: "Context threat",
};
export function Metrics({ metrics }: { metrics: Record<string, Metric> }) {
  return (
    <div className="metrics">
      {Object.entries(labels).map(([key, label]) => {
        const item = metrics[key];
        return (
          <div className="metric" key={key}>
            <div>
              <span>{label}</span>
              <b>{item?.score == null ? "—" : `${Math.round(item.score)}%`}</b>
            </div>
            <div className="meter">
              <span style={{ width: `${item?.score || 0}%` }} />
            </div>
            <Source value={item?.source || "NOT_CONFIGURED"} />
            {item?.model && <small>{item.model} · Jabberjay</small>}
          </div>
        );
      })}
    </div>
  );
}
export function Transcript({
  text,
  signals = [],
}: {
  text: string;
  signals?: Incident["signals"];
}) {
  const spans = signals
    .flatMap((s) =>
      (s.matches || []).map((m) => ({ ...m, explanation: s.explanation })),
    )
    .sort((a, b) => a.start - b.start);
  let cursor = 0;
  const nodes: React.ReactNode[] = [];
  spans.forEach((m, i) => {
    if (m.start < cursor) return;
    nodes.push(text.slice(cursor, m.start));
    nodes.push(
      <mark key={i} title={m.explanation}>
        {text.slice(m.start, m.end)}
      </mark>,
    );
    cursor = m.end;
  });
  nodes.push(text.slice(cursor));
  return (
    <blockquote className="transcript">
      {text ? (
        <>“{nodes}”</>
      ) : (
        <span className="muted">
          No transcript retained. Acoustic analysis is independent of
          transcription.
        </span>
      )}
    </blockquote>
  );
}
export function ErrorNotice({ message }: { message: string }) {
  return (
    <div className="notice error" role="alert">
      <AlertCircle size={19} />
      <span>{message}</span>
    </div>
  );
}
export function Cursor() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const fine = window.matchMedia(
      "(pointer:fine) and (hover:hover) and (prefers-reduced-motion:no-preference)",
    );
    if (!fine.matches) return;
    let tx = -100,
      ty = -100,
      x = -100,
      y = -100,
      frame = 0;
    const move = (e: PointerEvent) => {
      tx = e.clientX;
      ty = e.clientY;
      const target = (e.target as Element).closest<HTMLElement>(
        "[data-cursor],a,button",
      );
      if (ref.current) {
        ref.current.textContent = target?.dataset.cursor || "";
        ref.current.classList.toggle("expanded", !!target);
        ref.current.style.opacity = "1";
      }
    };
    const hide = () => {
      if (ref.current) ref.current.style.opacity = "0";
    };
    const tick = () => {
      x += (tx - x) * 0.22;
      y += (ty - y) * 0.22;
      if (ref.current)
        ref.current.style.transform = `translate3d(${x}px,${y}px,0) translate(-50%,-50%)`;
      frame = requestAnimationFrame(tick);
    };
    window.addEventListener("pointermove", move);
    document.addEventListener("pointerleave", hide);
    frame = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("pointermove", move);
      document.removeEventListener("pointerleave", hide);
    };
  }, []);
  return <div ref={ref} className="vox-cursor" aria-hidden="true" />;
}
export function Reveal({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.classList.add("revealed");
          obs.disconnect();
        }
      },
      { threshold: 0.08 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return (
    <div className={`reveal ${className}`} ref={ref}>
      {children}
    </div>
  );
}
export function ArchitectureGraphic() {
  const stages = [
    { icon: AudioLines, title: "audio in", desc: "WAV / FLAC · 16 kHz mono" },
    {
      icon: ScanLine,
      title: "listen deeper",
      desc: "HuBERT + energy & pause features",
    },
    {
      icon: Activity,
      title: "assess risk",
      desc: "Acoustic evidence + English context",
    },
    {
      icon: GitBranch,
      title: "apply policy",
      desc: "Thresholds depend on the action",
    },
    {
      icon: PhoneCall,
      title: "verify first",
      desc: "Callback · MFA · supervisor",
    },
  ];
  return (
    <div className="architecture-flow">
      {stages.map(({ icon: Icon, title, desc }, i) => (
        <div className="flow-stage" key={title}>
          <span className="flow-number">0{i + 1}</span>
          <Icon size={25} />
          <h3>{title}</h3>
          <p>{desc}</p>
          {i < stages.length - 1 && (
            <ArrowRight className="flow-arrow" size={18} />
          )}
        </div>
      ))}
    </div>
  );
}
export const appLinks = [
  { to: "/console", name: "Overview", icon: LayoutDashboard },
  { to: "/demo", name: "Live analysis", icon: AudioLines },
  { to: "/incidents", name: "Incidents", icon: List },
  { to: "/voice-profiles", name: "Voice profiles", icon: Users },
  { to: "/architecture", name: "Architecture", icon: GitBranch },
  { to: "/settings", name: "Settings", icon: SlidersHorizontal },
];
export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="app-layout">
      <aside className="sidebar">
        <Brand />
        <div className="workspace">
          <span className="workspace-avatar">V</span>
          <div>
            Voxsus workspace<small>local prototype</small>
          </div>
        </div>
        <nav aria-label="Console navigation">
          {appLinks.map(({ to, name, icon: Icon }) => (
            <NavLink key={to} to={to} end>
              <Icon size={18} />
              {name}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-note">
          <Check size={17} />
          <p>
            Less audio retained.
            <br />
            <span>More informed decisions.</span>
          </p>
        </div>
        <Link to="/" className="back-home">
          Back to website <ArrowUpRight size={16} />
        </Link>
      </aside>
      <div className="app-body">
        <div className="app-topbar">
          <span>
            <i className="status-dot" /> LOCAL WORKSPACE
          </span>
          <span>
            SIH 26104 <span className="avatar">VX</span>
          </span>
        </div>
        <main id="main-content" className="app-main">
          {children}
        </main>
      </div>
    </div>
  );
}
