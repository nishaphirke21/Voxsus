def evaluate(
    score: int | None, workflow: str, thresholds: dict, detector_available: bool, signals: list
) -> dict:
    threshold = thresholds[workflow]
    sensitive = any(
        s["type"] in {"credential_request", "anti_verification", "high_value_transfer"} for s in signals
    )
    required = not detector_available or score is None or score >= threshold or sensitive
    reason = (
        "Voice engine unavailable; identity is unverified."
        if not detector_available
        else "Sensitive request requires independent verification."
        if sensitive
        else f"Risk meets the {threshold}-point policy threshold."
        if required
        else "Below this workflow's alert threshold; this does not prove identity."
    )
    return {
        "threshold": threshold,
        "workflow": workflow,
        "verification_required": required,
        "recommendation": "Pause sensitive action. Verify through a registered callback, MFA or supervisor."
        if required
        else "Continue with normal verification procedures.",
        "reason": reason,
        "enforced": False,
    }
