"""Transparent prototype index, not a calibrated fraud probability."""

import math

WEIGHTS = {"synthetic": 0.40, "speaker": 0.25, "prosody": 0.15, "context": 0.20}


def fuse(signals: dict[str, float | None]) -> dict:
    observed = {key: value for key, value in signals.items() if value is not None and key in WEIGHTS}
    if any(not math.isfinite(v) or not 0 <= v <= 100 for v in observed.values()):
        raise ValueError("Scores must be finite and between 0 and 100")
    coverage = sum(WEIGHTS[k] for k in observed)
    score = round(sum(WEIGHTS[k] * v for k, v in observed.items()) / coverage) if coverage else None
    return {
        "score": score,
        "level": level(score),
        "coverage": round(coverage * 100),
        "missing": [k for k in WEIGHTS if signals.get(k) is None],
        "weights": WEIGHTS,
    }


def level(score: int | None) -> str:
    if score is None:
        return "UNKNOWN"
    return "CRITICAL" if score >= 80 else "HIGH" if score >= 60 else "CAUTION" if score >= 30 else "LOW"
