# Initial audit — 19 September 2026

The supplied workspace contained only empty work/ and outputs/ directories. There was no Git repository, remote, application, dependencies, model code, or existing user implementation to preserve. The SIH 26104 document is background; the pasted master prompt is the user's request. A new local repository is built in outputs/voxsus. No other SIH implementation is used. No GitHub remote was supplied; local commits are checkpoints, not a claim of publication.

## Live design reference

Opened https://www.heyclicky.com/?ref=saaspo.com in the live browser. Reviewed 1440×900, 1280×800, 1024×768, 768×1024, and 390×844 viewports. The current site is a Mac AI companion, with a pale dotted canvas, loose desktop-object composition, huge centered lowercase headline, glossy pill CTAs, soft shadows, video windows, stickers, and ample whitespace. Desktop navigation resembles a menu bar. Tablet/mobile remove peripheral media, stack CTAs and switch navigation to a menu. Feature sections alternate descriptive copy and media; later sections use a notes-window treatment, testimonials, pricing and accordion FAQ. Observed headline computed style: Inter 88px on desktop, major section headings 56px. Native pointer was available; no identifiable custom-cursor DOM node was found, so exact cursor physics are not claimed to be reverse engineered. Browser capture had duplicated edge strips at some sizes; layout conclusions also used DOM and visible central content.

Voxsus interpretation: original V-shaped voice mark, pale dot grid, Manrope display type + DM Sans body, cobalt tactile controls, floating voice evidence slips, original SVG voiceprint, restrained hand annotations and alternating open/structured sections. No proprietary graphics, videos, copy, logos, or source code are reused. A custom pointer companion is an original feature, with native cursor fallback.

## Jabberjay assessment

Inspected source at commit `093999df92dd3f37e514d8b87dc96fb38def802e`, version 0.1.1. MIT license, copyright Matthew Boakes and The Alan Turing Institute (2024–2026). Python >=3.12. Dependencies include PyTorch, transformers, librosa, scipy, soundfile. Model downloads use Hugging Face and are cached; pipeline loaders are cached in memory. CPU, CUDA and MPS are selected automatically. Public call: `Jabberjay().detect((float32_mono_samples, 16000), model='HuBERT')`. Result contains label, confidence, is_bonafide, model and full scores. Top-label confidence is NOT automatically synthetic probability; the Spoof score must be extracted.

HuBERT is selected to avoid loading several costly detectors. Its repository is `abhishtagatya/hubert-base-960h-itw-deepfake`. Other supported model families include Wav2Vec2, WavLM, AST, ViT and Spectra. These alternatives are not presented as running. Upstream accepts formats decoded by librosa/soundfile; Voxsus deliberately limits uploads to WAV/FLAC, 20 MB and 60 seconds, decoded mono at 16 kHz. The actual installation and measured inference results are recorded in VALIDATION.md.

Initial Git HTTPS clone failed with the Windows credential backend; a per-command OpenSSL TLS backend succeeded with certificate validation intact. No global Git settings were changed.
