# voxsus

Voxsus is a local Smart India Hackathon prototype for continuous voice-integrity and impersonation-risk assessment. It combines a real synthetic-speech detector through [Jabberjay](https://github.com/MattyB95/Jabberjay), lightweight prosody features, English contextual-threat rules, transparent risk fusion, configurable policy thresholds, and incident review.

The included presentation scenarios use clearly labeled deterministic demo scores. Uploaded WAV/FLAC files use actual model inference. Voxsus is a prototype and does not prove identity, block transactions, or connect to telecom/banking systems.

## What is included

- `frontend/` — React 19, TypeScript, Vite, CSS, SVG and bundled narration assets
- `backend/` — FastAPI endpoints, upload controls, SQLite persistence and static frontend serving
- `analysis/` — audio decoding, Jabberjay adapter, prosody and contextual analysis
- `risk/` — risk fusion and policy recommendation logic
- `tests/` — backend, API, risk and privacy tests
- `docs/` — design audit, model validation results and Jabberjay license
- `samples/` — deterministic presentation-scenario data
- `frontend/dist/` — production frontend build, included for convenience

Dependency folders, downloaded model weights, the local incident database, Git history and caches are intentionally excluded from the source archive. They are generated locally.

## Requirements

- Python 3.12 or newer
- Node.js 20 or newer and npm
- Internet access during the first installation and first model load
- Several gigabytes of free disk space for Python packages and model weights

## Run locally

From the `voxsus` directory, create a Python environment and install the backend:

### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
npm.cmd install --prefix frontend
npm.cmd run build --prefix frontend
.\.venv\Scripts\python.exe -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

### macOS or Linux

```bash
python3 -m venv .venv
./.venv/bin/python -m pip install -r requirements.txt
npm install --prefix frontend
npm run build --prefix frontend
./.venv/bin/python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000`. Keep the server bound to localhost: authentication is not implemented in this hackathon prototype.

On first start, Jabberjay downloads the configured HuBERT model from Hugging Face. The marketing page and presentation demo remain available while the model initializes. Check readiness at `http://127.0.0.1:8000/api/health`.

For frontend development with hot reload, run the backend command above and, in another terminal:

```bash
npm run dev --prefix frontend
```

Then open `http://127.0.0.1:5173`.

## Verify the project

```powershell
npm.cmd run lint --prefix frontend
npm.cmd run typecheck --prefix frontend
npm.cmd run build --prefix frontend
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m ruff check .
```

Use `python scripts/verify_model.py` to repeat real inference against the two upstream Jabberjay validation clips. Those clips are downloaded into the ignored `samples/validation/` directory. Existing measured results are included under `docs/`.

## Data and model behavior

- Uploads accept WAV/FLAC, up to 20 MB and 60 seconds.
- Audio is decoded and processed temporarily; raw audio is not persisted.
- Transcript retention is opt-in. Scores, recommendations and operator actions are stored in local SQLite.
- Real analysis uses one HuBERT detector. Speaker verification and automatic transcription are visibly unavailable.
- The risk score is an uncalibrated prototype index, not a probability of fraud.
- The included validation shows a serious false negative: HuBERT and Wav2Vec2 both scored the upstream spoof sample as low synthetic probability. See `docs/validation-hubert.json`, `docs/validation-wav2vec2.json` and `docs/api-validation.json`.

## Credits and licenses

Voxsus uses Jabberjay 0.1.1 as its synthetic-voice detector abstraction. Jabberjay is MIT licensed; its license is included at `docs/JABBERJAY_LICENSE.txt`. The selected HuBERT model repository declares Apache-2.0. Frontend dependencies retain their own licenses in the installed packages.
