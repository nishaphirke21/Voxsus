import io
import math

import numpy as np
import pytest
import soundfile as sf
from fastapi.testclient import TestClient

from analysis.audio import decode
from analysis.context_analysis import analyze_context
from backend.main import app
from risk.engine import fuse, level
from risk.policy import evaluate


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("VOXSUS_DB", str(tmp_path / "test.db"))
    monkeypatch.setenv("VOXSUS_WARMUP", "0")
    with TestClient(app) as c:
        yield c


def audio_bytes(seconds=2, sr=16000):
    target = io.BytesIO()
    sf.write(target, np.sin(np.arange(int(sr * seconds)) * 0.1).astype(np.float32) * 0.2, sr, format="WAV")
    return target.getvalue()


def test_fusion_missing_is_not_zero():
    score = fuse({"synthetic": 80, "speaker": None, "prosody": 50, "context": 90})
    assert score["score"] == 77
    assert score["coverage"] == 75
    assert score["missing"] == ["speaker"]
    assert fuse({})["score"] is None


@pytest.mark.parametrize(
    "score,expected",
    [
        (0, "LOW"),
        (29, "LOW"),
        (30, "CAUTION"),
        (59, "CAUTION"),
        (60, "HIGH"),
        (79, "HIGH"),
        (80, "CRITICAL"),
        (100, "CRITICAL"),
        (None, "UNKNOWN"),
    ],
)
def test_risk_boundaries(score, expected):
    assert level(score) == expected


@pytest.mark.parametrize("value", [-1, 101, math.nan, math.inf])
def test_reject_invalid_scores(value):
    with pytest.raises(ValueError):
        fuse({"synthetic": value})


def test_context_independent_sensitive_policy():
    context = analyze_context("Transfer ₹25 lakh immediately. Don't call me back. Keep this confidential.")
    kinds = {x["type"] for x in context["signals"]}
    assert {"high_value_transfer", "urgency", "anti_verification", "secrecy"} <= kinds
    policy = evaluate(10, "payment", {"payment": 45}, True, context["signals"])
    assert policy["verification_required"]
    assert not policy["enforced"]
    assert analyze_context("Please send today's sales report.")["score"] == 0
    assert evaluate(0, "normal", {"normal": 75}, False, [])["verification_required"]


def test_workflow_threshold_changes_action():
    assert not evaluate(52, "normal", {"normal": 75}, True, [])["verification_required"]
    assert evaluate(52, "payment", {"payment": 45}, True, [])["verification_required"]


def test_audio_limits():
    with pytest.raises(ValueError):
        decode(b"not audio")
    with pytest.raises(ValueError):
        decode(audio_bytes(0.2))
    with pytest.raises(ValueError):
        decode(audio_bytes(61))
    samples, sr = decode(audio_bytes(2, 44100))
    assert sr == 16000 and len(samples) == 32000


def test_demo_policy_persistence_and_actions(client):
    assert client.get("/api/health").status_code == 200
    assert client.get("/api/incidents").json() == []
    a = client.post("/api/demo", json={"scenario": "genuine"}).json()
    b = client.post("/api/demo", json={"scenario": "cloned"}).json()
    assert a["risk"]["score"] == 12 and a["mode"] == "DEMO_ANALYSIS"
    assert b["risk"]["score"] == 87 and b["policy"]["verification_required"]
    assert client.get("/api/incidents/" + b["id"]).json()["timeline"] == [18, 26, 39, 57, 73, 87]
    action = client.patch(
        "/api/incidents/" + b["id"],
        json={"action": "Callback requested", "note": "Operator to call registered number."},
    ).json()
    assert action["history"][0]["action"] == "Callback requested"
    assert client.patch("/api/incidents/" + b["id"], json={"action": "send money"}).status_code == 422
    assert client.get("/api/incidents/missing").status_code == 404
    assert (
        client.put("/api/settings", json={"normal": 72, "payment": 35, "privileged": 30}).status_code == 200
    )
    assert client.get("/api/settings").json()["payment"] == 35
    assert client.put("/api/settings", json={"payment": 101}).status_code == 422
    assert client.get("/api/incidents/" + b["id"]).json()["policy"]["threshold"] == 45


def test_upload_validation(client):
    assert client.post("/api/analyze", files={"file": ("evil.mp3", b"bad", "audio/mpeg")}).status_code == 415
    assert client.post("/api/analyze", files={"file": ("bad.wav", b"bad", "audio/wav")}).status_code == 422
    assert (
        client.post("/api/analyze", files={"file": ("short.wav", audio_bytes(0.2), "audio/wav")}).status_code
        == 422
    )
    assert (
        client.post(
            "/api/analyze", files={"file": ("large.wav", b"0" * (20 * 1024 * 1024 + 1), "audio/wav")}
        ).status_code
        == 413
    )


def test_model_failure_never_becomes_demo(client, monkeypatch):
    from backend.main import detector

    def fail(*args):
        raise RuntimeError("weights unavailable")

    monkeypatch.setattr(detector, "detect", fail)
    response = client.post("/api/analyze", files={"file": ("voice.wav", audio_bytes(), "audio/wav")})
    assert response.status_code == 503
    assert client.get("/api/incidents").json() == []


def test_real_pipeline_retention_and_chunks(client, monkeypatch):
    from backend.main import detector

    calls = []

    def model(samples, sr):
        calls.append(len(samples) / sr)
        return {
            "score": 80,
            "source": "REAL_MODEL",
            "model": "test-double",
            "synthetic_probability": 0.8,
            "latency_ms": 1,
        }

    monkeypatch.setattr(detector, "detect", model)
    response = client.post(
        "/api/analyze",
        files={"file": ("voice.wav", audio_bytes(10.5), "audio/wav")},
        data={"transcript": "Send the OTP immediately.", "retain_transcript": "false"},
    )
    assert response.status_code == 201
    item = response.json()
    assert calls == [5, 5.5]
    assert item["mode"] == "REAL_ANALYSIS" and item["transcript"] == ""
    assert item["metrics"]["speaker"]["score"] is None
    assert item["risk"]["coverage"] == 75
    assert all("matches" not in s for s in item["signals"])
    assert item["raw_audio_retained"] is False
    assert item["policy"]["verification_required"]
    retained = client.post(
        "/api/analyze/chunk",
        files={"file": ("voice.wav", audio_bytes(), "audio/wav")},
        data={"transcript": "hello", "retain_transcript": "true"},
    ).json()
    assert retained["transcript"] == "hello"
    assert client.get("/api/unknown").status_code == 404
